using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Jangmao70
{
    internal static class DisplayRegression
    {
        private static Button FindGenerate(Control root)
        {
            foreach (Control child in root.Controls)
            {
                var button = child as Button;
                if (button != null && button.Text.Contains("ตรวจสอบและสร้าง")) return button;
                var found = FindGenerate(child);
                if (found != null) return found;
            }
            return null;
        }

        [STAThread]
        private static int Main()
        {
            try
            {
                Application.EnableVisualStyles();
                using (var form = new Jangmao70ShellForm())
                {
                    form.Opacity = 0;
                    form.ShowInTaskbar = false;
                    form.Show();
                    Application.DoEvents();
                    var tabs = form.Controls.OfType<TabControl>().Single();
                    foreach (var size in new[] { new Size(1280, 680), new Size(1024, 680), new Size(960, 600), new Size(800, 500) })
                    {
                        form.Size = size;
                        Application.DoEvents();
                        if (form.Width > size.Width || form.Height > size.Height) throw new Exception("Window minimum exceeds available area: " + size + " actual=" + form.Size);
                        for (var i = 0; i < tabs.TabCount; i++)
                        {
                            tabs.SelectedIndex = i;
                            Application.DoEvents();
                            var page = tabs.TabPages[i];
                            var generate = FindGenerate(page);
                            if (generate == null) throw new Exception("Generate button missing: " + page.Text);
                            page.ScrollControlIntoView(generate);
                            Application.DoEvents();
                            var bounds = page.RectangleToClient(generate.RectangleToScreen(generate.ClientRectangle));
                            if (!page.ClientRectangle.Contains(bounds) || !generate.Visible || !generate.Enabled)
                                throw new Exception("Generate button cannot be reached: " + size + " tab=" + page.Text + " button=" + bounds + " viewport=" + page.ClientRectangle);
                            Console.WriteLine("PASS " + size + " " + page.Text + ": generate button reachable");
                            if (size.Width == 1024)
                            {
                                using (var bitmap = new Bitmap(form.Width, form.Height))
                                {
                                    form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
                                    bitmap.Save(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "small-screen-tab-" + i + ".png"));
                                }
                            }
                        }
                    }
                }
                return 0;
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        }
    }
}
