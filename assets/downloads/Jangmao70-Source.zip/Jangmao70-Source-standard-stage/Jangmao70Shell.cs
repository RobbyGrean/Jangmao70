using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace Jangmao70
{
    internal static class Jangmao70ShellProgram
    {
        [STAThread]
        private static void Main()
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += HandleThreadException;
            AppDomain.CurrentDomain.UnhandledException += HandleUnhandledException;
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Jangmao70ShellForm());
            }
            catch (Exception ex)
            {
                ReportException(ex, true);
            }
        }

        private static void HandleThreadException(object sender, ThreadExceptionEventArgs e)
        {
            ReportException(e.Exception, true);
        }

        private static void HandleUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var exception = e.ExceptionObject as Exception;
            ReportException(exception ?? new Exception(Convert.ToString(e.ExceptionObject)), !e.IsTerminating);
        }

        private static void ReportException(Exception ex, bool showDialog)
        {
            var details = ex == null ? "ไม่ทราบรายละเอียดข้อผิดพลาด" : ex.ToString();
            try
            {
                Directory.CreateDirectory(Jangmao70Paths.DataRoot);
                File.WriteAllText(Path.Combine(Jangmao70Paths.DataRoot, "startup-error.log"), DateTime.Now.ToString("O") + Environment.NewLine + details);
            }
            catch
            {
            }
            if (!showDialog) return;
            try
            {
                MessageBox.Show("เปิด Jangmao70 ไม่สำเร็จ\n\n" + details, "Jangmao70 เกิดข้อผิดพลาด", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch
            {
            }
        }
    }
    internal sealed class Jangmao70ShellForm : Form
    {
        private readonly TabControl tabs = new TabControl();
        private Form payrollForm;
        private ProcurementModule procurementModule;
        private bool closingConfirmed;
        private readonly Button updateButton = new Button();
        private bool updateInProgress;
        private string pendingInstaller;
        private UpdateManifest pendingManifest;

        public Jangmao70ShellForm()
        {
            Text = "Jangmao70 " + Jangmao70Update.VersionText;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new System.Drawing.Size(1220, 850);
            MinimumSize = new System.Drawing.Size(1080, 760);
            BackColor = Color.FromArgb(243, 246, 248);
            Font = new Font("Segoe UI", 10f);
            tabs.Dock = DockStyle.Fill;
            tabs.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabs.SizeMode = TabSizeMode.Fixed;
            tabs.ItemSize = new Size(210, 30);
            tabs.Padding = new Point(16, 2);
            tabs.DrawItem += DrawTab;
            Controls.Add(tabs);
            BuildUpdateBar();

            BuildProcurementTab();
            BuildPayrollTab();
            tabs.SelectedIndex = 0;
            FormClosing += HandleFormClosing;
            FormClosed += delegate
            {
                if (pendingInstaller == null) return;
                try { Jangmao70Update.StartInstaller(pendingInstaller, pendingManifest); }
                catch (Exception ex) { MessageBox.Show("เปิดตัวติดตั้งไม่สำเร็จ กรุณาเปิดโปรแกรมแล้วลองอัปเดตใหม่\n\n" + ex.Message, "อัปเดต Jangmao70", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            Shown += delegate
            {
                try
                {
                    var result = Jangmao70Update.ReadUpdateResult();
                    if (result != null) MessageBox.Show(this, result, "ผลการอัปเดต Jangmao70");
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "ตรวจสอบการอัปเดต", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
        }

        private void BuildUpdateBar()
        {
            var bar = new Panel { Dock = DockStyle.Top, Width = ClientSize.Width, Height = 46, BackColor = Color.White };
            var version = new Label { Text = "Jangmao70  |  รุ่น " + Jangmao70Update.VersionText, AutoSize = true, Location = new Point(14, 13) };
            updateButton.Text = "อัปเดตโปรแกรม";
            updateButton.Size = new Size(180, 32);
            updateButton.Location = new Point(ClientSize.Width - 194, 7);
            updateButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            updateButton.Click += async delegate { await UpdateProgramAsync(); };
            var details = new Button { Text = "ข้อมูลโปรแกรม", Size = new Size(130, 32), Location = new Point(ClientSize.Width - 334, 7), Anchor = AnchorStyles.Top | AnchorStyles.Right };
            details.Click += delegate
            {
                var hash = File.Exists(Jangmao70Update.DatabasePath) ? Jangmao70Update.HashFile(Jangmao70Update.DatabasePath) : "ไม่พบไฟล์";
                MessageBox.Show(this, "รุ่นโปรแกรม: " + Jangmao70Update.VersionText + "\n\nโปรแกรมที่เปิดอยู่:\n" + Application.ExecutablePath + "\n\nตารางวันที่ส่งเบิก:\n" + Jangmao70Update.DatabasePath + "\n\nSHA256 ตาราง:\n" + hash, "ข้อมูล Jangmao70");
            };
            bar.Controls.Add(version);
            bar.Controls.Add(details);
            bar.Controls.Add(updateButton);
            Controls.Add(bar);
        }

        private async System.Threading.Tasks.Task UpdateProgramAsync()
        {
            updateInProgress = true;
            updateButton.Enabled = false;
            updateButton.Text = "กำลังตรวจสอบ...";
            try
            {
                var manifest = await Jangmao70Update.CheckAsync();
                if (!Jangmao70Update.NeedsUpdate(manifest))
                {
                    MessageBox.Show(this, "รุ่นปัจจุบัน " + Jangmao70Update.VersionText + " ไม่ต้องอัปเดต", "อัปเดต Jangmao70");
                    return;
                }
                if (MessageBox.Show(this, "พร้อมติดตั้งรุ่น " + manifest.version + "\nโปรแกรมจะดาวน์โหลดตัวติดตั้ง แล้วให้บันทึกงานก่อนปิด\nหลังติดตั้งเสร็จ เลือกเปิด Jangmao70 อีกครั้ง\n\nต้องการดำเนินการหรือไม่?", "อัปเดต Jangmao70", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                pendingInstaller = await Jangmao70Update.DownloadAsync(manifest, delegate(int percent) { updateButton.Text = "ดาวน์โหลด " + percent + "%"; });
                pendingManifest = manifest;
                updateInProgress = false;
                Close(); // Existing save/cancel flow runs before FormClosed launches the installer.
                if (!IsDisposed) { pendingInstaller = null; pendingManifest = null; }
            }
            catch (Exception ex)
            {
                pendingInstaller = null;
                pendingManifest = null;
                MessageBox.Show(this, "อัปเดตไม่สำเร็จ โปรแกรมและข้อมูลเดิมยังใช้งานได้\nกรุณาตรวจสอบอินเทอร์เน็ต หรือลองใหม่ภายหลัง\n\n" + ex.Message, "อัปเดต Jangmao70", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                updateInProgress = false;
                if (!IsDisposed) { updateButton.Enabled = true; updateButton.Text = "อัปเดตโปรแกรม"; }
            }
        }

        private void DrawTab(object sender, DrawItemEventArgs e)
        {
            var selected = e.Index == tabs.SelectedIndex;
            var accent = e.Index == 0 ? Color.FromArgb(15, 118, 110) : Color.FromArgb(31, 94, 140);
            var background = selected ? accent : Color.White;
            var foreground = selected ? Color.White : Color.FromArgb(30, 41, 59);
            using (var backgroundBrush = new SolidBrush(background))
            using (var foregroundBrush = new SolidBrush(foreground))
                using (var font = new Font(tabs.Font, selected ? FontStyle.Bold : FontStyle.Regular))
            {
                e.Graphics.FillRectangle(backgroundBrush, e.Bounds);
                var textBounds = new Rectangle(e.Bounds.Left + 8, Math.Max(0, e.Bounds.Top + 3), e.Bounds.Width - 16, Math.Max(1, e.Bounds.Height - 6));
                e.Graphics.DrawString(tabs.TabPages[e.Index].Text, font, foregroundBrush, textBounds, new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center });
            }
            e.DrawFocusRectangle();
        }

        private void BuildPayrollTab()
        {
            var page = new TabPage("เบิกเงินเดือน") { BackColor = Color.FromArgb(243, 246, 248), AutoScroll = true };
            payrollForm = CreateLegacyPayrollForm();
            payrollForm.TopLevel = false;
            payrollForm.FormBorderStyle = FormBorderStyle.None;
            payrollForm.Dock = DockStyle.Fill;
            page.Controls.Add(payrollForm);
            payrollForm.Show();
            tabs.TabPages.Add(page);
        }

        private void BuildProcurementTab()
        {
            var page = new TabPage("จัดซื้อจัดจ้างและสัญญา") { BackColor = Color.FromArgb(243, 246, 248) };
            procurementModule = new ProcurementModule(WorkingRecord.CreateEmpty(), null);
            page.Controls.Add(procurementModule);
            tabs.TabPages.Add(page);
        }

        private Form CreateLegacyPayrollForm()
        {
            var programType = typeof(Program);
            var loadTemplates = programType.GetMethod("LoadTemplates", BindingFlags.NonPublic | BindingFlags.Static);
            var templates = loadTemplates.Invoke(null, null);
            var mainFormType = programType.GetNestedType("MainForm", BindingFlags.NonPublic);
            var form = (Form)Activator.CreateInstance(mainFormType, new[] { templates });
            var templateBox = GetPrivateField(form, "templateBox") as TextBox;
            var outputBox = GetPrivateField(form, "outputBox") as TextBox;
            var templateRoot = Jangmao70Paths.EnsureUserTemplateRoot(DocumentModule.Payroll);
            if (templateBox != null) templateBox.Text = templateRoot;
            if (outputBox != null) outputBox.Text = Jangmao70Paths.OutputRoot(DocumentModule.Payroll);
            return form;
        }

        private void HandleFormClosing(object sender, FormClosingEventArgs e)
        {
            if (updateInProgress)
            {
                e.Cancel = true;
                MessageBox.Show(this, "กำลังตรวจสอบหรือดาวน์โหลดอัปเดต กรุณารอให้เสร็จก่อนปิดโปรแกรม", "อัปเดต Jangmao70");
                return;
            }
            if (closingConfirmed || procurementModule == null) return;
            var procurementHasChanges = procurementModule.IsDirty;
            var payrollHasChanges = IsPayrollDirty();
            var choice = MessageBox.Show("ก่อนออกจากโปรแกรม ต้องการบันทึก Template ที่จัดทำค้างไว้หรือไม่?\nใช่ = บันทึกข้อมูลที่แก้ไข, ไม่ใช่ = ออกโดยไม่บันทึก, ยกเลิกหรือกากบาท = กลับไปทำงาน", "ปิด Jangmao70", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Cancel)
            {
                e.Cancel = true;
                return;
            }
            if (choice == DialogResult.Yes)
            {
                if (payrollHasChanges && !SavePayrollDraftForExit())
                {
                    e.Cancel = true;
                    return;
                }
                if (procurementHasChanges)
                {
                    var result = procurementModule.SaveCurrentTemplate();
                    if (result != TemplateOperationResult.Saved)
                    {
                        e.Cancel = true;
                        return;
                    }
                }
            }
            closingConfirmed = true;
        }

        private bool IsPayrollDirty()
        {
            if (payrollForm == null) return false;
            var property = payrollForm.GetType().GetProperty("IsDirty", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (property == null) return false;
            var value = property.GetValue(payrollForm, null);
            return value is bool && (bool)value;
        }

        private bool SavePayrollDraftForExit()
        {
            if (payrollForm == null) return true;
            var method = payrollForm.GetType().GetMethod("SaveDraftForExit", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (method == null) return true;
            try
            {
                var result = method.Invoke(payrollForm, null);
                return !(result is bool) || (bool)result;
            }
            catch (TargetInvocationException ex)
            {
                var message = ex.InnerException == null ? ex.Message : ex.InnerException.Message;
                MessageBox.Show("บันทึกข้อมูลเบิกเงินเดือนก่อนปิดไม่สำเร็จ: " + message, "บันทึกข้อมูล", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("บันทึกข้อมูลเบิกเงินเดือนก่อนปิดไม่สำเร็จ: " + ex.Message, "บันทึกข้อมูล", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private static object GetPrivateField(object instance, string name)
        {
            if (instance == null) return null;
            var field = instance.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic);
            return field == null ? null : field.GetValue(instance);
        }

    }
}
