using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace Jangmao70
{
    internal static class DisplayRegression
    {
        public static DateTime Today = DateTime.Today;
        private static Button FindGenerate(Control root)
        {
            foreach (Control child in root.Controls)
            {
                var button = child as Button;
                if (button != null && button.Text.Contains("ตรวจสอบและสร้าง")) return button;
                var found = FindGenerate(child);
                if (found != null) return found;
            }
            return null;
        }

        [STAThread]
        private static int Main()
        {
            try
            {
                Application.EnableVisualStyles();
                var cases = new[] {
                    new { Today = new DateTime(2026, 11, 3), Month = "ตุลาคม", Year = 2569 },
                    new { Today = new DateTime(2027, 1, 3), Month = "ธันวาคม", Year = 2569 },
                    new { Today = new DateTime(2026, 10, 1), Month = "กันยายน", Year = 2569 },
                    new { Today = new DateTime(2028, 3, 31), Month = "กุมภาพันธ์", Year = 2571 }
                };
                foreach (var test in cases)
                {
                    Today = test.Today;
                    using (var shell = new Jangmao70ShellForm())
                    {
                        var flags = BindingFlags.Instance | BindingFlags.NonPublic;
                        var payroll = typeof(Jangmao70ShellForm).GetField("payrollForm", flags).GetValue(shell);
                        var month = (ComboBox)payroll.GetType().GetField("fiscalMonthBox", flags).GetValue(payroll);
                        var year = (NumericUpDown)payroll.GetType().GetField("fiscalYearBox", flags).GetValue(payroll);
                        if ((string)month.SelectedItem != test.Month || year.Value != test.Year)
                            throw new Exception("Incorrect previous delivery month/year for " + Today.ToString("yyyy-MM-dd"));
                        Console.WriteLine("PASS startup " + Today.ToString("yyyy-MM-dd") + " -> " + test.Month + " " + test.Year);
                    }
                }
                Today = DateTime.Today;
                using (var form = new Jangmao70ShellForm())
                {
                    form.Opacity = 0;
                    form.ShowInTaskbar = false;
                    form.Show();
                    Application.DoEvents();
                    var tabs = form.Controls.OfType<TabControl>().Single();
                    foreach (var size in new[] { new Size(1280, 680), new Size(1024, 680), new Size(960, 600), new Size(800, 500) })
                    {
                        form.Size = size;
                        Application.DoEvents();
                        if (form.Width > size.Width || form.Height > size.Height) throw new Exception("Window minimum exceeds available area: " + size + " actual=" + form.Size);
                        for (var i = 0; i < tabs.TabCount; i++)
                        {
                            tabs.SelectedIndex = i;
                            Application.DoEvents();
                            var page = tabs.TabPages[i];
                            var generate = FindGenerate(page);
                            if (generate == null) throw new Exception("Generate button missing: " + page.Text);
                            page.ScrollControlIntoView(generate);
                            Application.DoEvents();
                            var bounds = page.RectangleToClient(generate.RectangleToScreen(generate.ClientRectangle));
                            if (!page.ClientRectangle.Contains(bounds) || !generate.Visible || !generate.Enabled)
                                throw new Exception("Generate button cannot be reached: " + size + " tab=" + page.Text + " button=" + bounds + " viewport=" + page.ClientRectangle);
                            Console.WriteLine("PASS " + size + " " + page.Text + ": generate button reachable");
                            if (size.Width == 1024)
                            {
                                using (var bitmap = new Bitmap(form.Width, form.Height))
                                {
                                    form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
                                    bitmap.Save(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "small-screen-tab-" + i + ".png"));
                                }
                            }
                        }
                    }
                }
                return 0;
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        }
    }
}
