#define MyAppName "Khet70"
#ifndef MyAppVersion
#define MyAppVersion "1.1.0"
#endif
#define MyAppPublisher "Khet70"
#define DistRoot "dist\Khet70"

[Setup]
AppId=Khet70
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Khet70
UsePreviousAppDir=no
DefaultGroupName={#MyAppName}
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
CloseApplications=yes
RestartApplications=no
Uninstallable=not IsIsolatedTest
UninstallDisplayName={#MyAppName}
UninstallDisplayIcon={app}\Khet70.exe
SetupIconFile=app-icon.ico
VersionInfoVersion={#MyAppVersion}.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription={#MyAppName} Installer
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
OutputBaseFilename=Khet70-Setup

[Files]
Source: "{#DistRoot}\Khet70.exe"; DestDir: "{app}"; Flags: ignoreversion restartreplace
Source: "{#DistRoot}\template_tags.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#DistRoot}\app_database.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#DistRoot}\Config\*"; DestDir: "{app}\Config"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#DistRoot}\Template\*"; DestDir: "{app}\Template"; Flags: ignoreversion recursesubdirs createallsubdirs uninsneveruninstall
Source: "{#DistRoot}\Defaults\Template\*"; DestDir: "{app}\Defaults\Template"; Flags: ignoreversion recursesubdirs createallsubdirs

Source: "{#DistRoot}\release-files.json"; DestDir: "{app}"; Flags: ignoreversion

[InstallDelete]
Type: files; Name: "{app}\Uninstall Khet70.exe"
Type: files; Name: "{app}\Template\Procurement\9. ใบสั่งจ้าง.docx"
Type: files; Name: "{app}\Defaults\Template\Procurement\9. ใบสั่งจ้าง.docx"

[Dirs]
Name: "{app}\Data"
Name: "{app}\Output\เงินเดือน"
Name: "{app}\Output\เอกสารจัดจ้าง"

[Icons]
Name: "{userdesktop}\Khet70"; Filename: "{app}\Khet70.exe"; WorkingDir: "{app}"; Check: not IsIsolatedTest
Name: "{userprograms}\Khet70\Khet70"; Filename: "{app}\Khet70.exe"; WorkingDir: "{app}"; Check: not IsIsolatedTest

[Run]
Filename: "{app}\Khet70.exe"; Description: "เปิด Khet70"; Flags: postinstall skipifsilent nowait; Check: AllowAutoRun

[Code]
function HasSwitch(const Value: String): Boolean;
var I: Integer;
begin
  Result := False;
  for I := 1 to ParamCount do
    if CompareText(ParamStr(I), Value) = 0 then Result := True;
end;

function IsIsolatedTest(): Boolean;
begin
  Result := HasSwitch('/ISOLATEDTEST');
end;

function AllowAutoRun(): Boolean;
begin
  Result := not HasSwitch('/NOAUTORUN');
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    SaveStringToFile(ExpandConstant('{app}\Data\.portable-state-migrated-v1'), 'Installed by Khet70 Setup', False);
end;

function CopyDirectoryContents(const SourceDir, TargetDir: String): Boolean;
var
  FindData: TFindRec;
  SourcePath, TargetPath: String;
begin
  Result := True;
  if not ForceDirectories(TargetDir) then
  begin
    Result := False;
    Exit;
  end;

  if FindFirst(AddBackslash(SourceDir) + '*', FindData) then
  try
    repeat
      if (FindData.Name <> '.') and (FindData.Name <> '..') then
      begin
        SourcePath := AddBackslash(SourceDir) + FindData.Name;
        TargetPath := AddBackslash(TargetDir) + FindData.Name;
        if (FindData.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0 then
        begin
          if not CopyDirectoryContents(SourcePath, TargetPath) then
          begin
            Result := False;
            Break;
          end;
        end
        else if not CopyFile(SourcePath, TargetPath, False) then
        begin
          Result := False;
          Break;
        end;
      end;
    until not FindNext(FindData);
  finally
    FindClose(FindData);
  end;
end;

function BackupUserTemplates(): Boolean;
var
  SourceDir, BackupRoot, BackupDir, BackupBase: String;
  Suffix: Integer;
begin
  Result := True;
  SourceDir := ExpandConstant('{app}\Template');
  if not DirExists(SourceDir) then Exit;

  BackupRoot := ExpandConstant('{app}\Data\TemplateBackups');
  if not ForceDirectories(BackupRoot) then
  begin
    Result := False;
    Exit;
  end;

  BackupBase := AddBackslash(BackupRoot) + 'Installer-' + GetDateTimeString('yyyymmdd-hhnnss', '-', ':');
  BackupDir := BackupBase;
  Suffix := 0;
  while DirExists(BackupDir) do
  begin
    Suffix := Suffix + 1;
    BackupDir := BackupBase + '-' + IntToStr(Suffix);
  end;
  Result := CopyDirectoryContents(SourceDir, BackupDir);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  Result := '';
  if not BackupUserTemplates() then
    Result := 'ไม่สามารถสำรอง Template เดิมก่อนติดตั้งได้ จึงหยุดการติดตั้งเพื่อป้องกันข้อมูลสูญหาย';
end;
