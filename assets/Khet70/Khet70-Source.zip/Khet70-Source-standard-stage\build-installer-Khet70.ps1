﻿param([switch]$AllowUnpublished)
# Standard Inno Setup release pipeline. Historical installers remain in release/legacy.
& (Join-Path $PSScriptRoot 'build-installer-standard-Khet70.ps1') -AllowUnpublished:$AllowUnpublished
