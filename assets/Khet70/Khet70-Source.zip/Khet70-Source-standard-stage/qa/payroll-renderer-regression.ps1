param(
    [string]$ExePath,
    [int]$TimeoutSeconds = 5
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $root 'dist\Khet70\Khet70.exe'
}
$ExePath = (Resolve-Path $ExePath).Path
$templatePath = (Resolve-Path (Join-Path $root 'Template\Payroll\3. ใบส่งมอบงาน.docx')).Path
$tagPath = Join-Path $root 'template_tags.json'
$tagMap = Get-Content -LiteralPath $tagPath -Raw | ConvertFrom-Json
$values = @{}
foreach ($tag in $tagMap.'3. ใบส่งมอบงาน.docx') {
    $values[$tag] = 'QA'
}

# This is the regression case: a user's literal value looks exactly like a business tag.
$values['{ชื่อลูกจ้าง}'] = '{ชื่อลูกจ้าง}'

$work = Join-Path $env:TEMP ('Khet70-payroll-render-regression-' + [Guid]::NewGuid().ToString('N'))
$outputPath = Join-Path $work 'output.docx'
New-Item -ItemType Directory -Path $work | Out-Null
$job = $null
try {
    $job = Start-Job -ScriptBlock {
        param($assemblyPath, $sourcePath, $targetPath, $inputKeys, $inputValues)

        $assembly = [Reflection.Assembly]::LoadFrom($assemblyPath)
        $rendererType = $assembly.GetType('Khet70.Program', $true)
        $renderer = $rendererType.GetMethod('RenderDocx', [Reflection.BindingFlags]::NonPublic -bor [Reflection.BindingFlags]::Static)
        if ($null -eq $renderer) { throw 'ไม่พบ Payroll renderer' }

        $dictionary = New-Object 'System.Collections.Generic.Dictionary[string,string]'
        for ($i = 0; $i -lt $inputKeys.Count; $i++) {
            $dictionary[[string]$inputKeys[$i]] = [string]$inputValues[$i]
        }
        Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Reflection;
public static class Khet70RegressionInvoker
{
    public static void Invoke(MethodInfo renderer, string sourcePath, string targetPath, Dictionary<string, string> values)
    {
        renderer.Invoke(null, new object[] { sourcePath, targetPath, values });
    }
}
'@
        [Khet70RegressionInvoker]::Invoke($renderer, $sourcePath, $targetPath, $dictionary)
    } -ArgumentList $ExePath, $templatePath, $outputPath, @($values.Keys), @($values.Values)

    $completed = Wait-Job -Job $job -Timeout $TimeoutSeconds
    if ($null -eq $completed) {
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        throw "FAIL: Payroll renderer ไม่จบภายใน $TimeoutSeconds วินาที (อาจเกิดลูปไม่จบ)"
    }
    Receive-Job -Job $job -ErrorAction Stop | Out-Null
    if (-not (Test-Path -LiteralPath $outputPath -PathType Leaf)) { throw 'FAIL: ไม่พบไฟล์ output จาก Payroll renderer' }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $containsLiteralTag = $false
    $package = [IO.Compression.ZipFile]::OpenRead($outputPath)
    try {
        foreach ($entry in $package.Entries) {
            if ($entry.FullName -notmatch '^word/(document|header\d+|footer\d+)\.xml$') { continue }
            $reader = New-Object IO.StreamReader($entry.Open())
            try {
                if ($reader.ReadToEnd().Contains('{ชื่อลูกจ้าง}')) { $containsLiteralTag = $true }
            }
            finally {
                $reader.Dispose()
            }
        }
    }
    finally {
        $package.Dispose()
    }
    if (-not $containsLiteralTag) { throw 'FAIL: ไม่พบค่าที่มีรูปแบบแท็กใน output' }
    Write-Host 'PASS: Payroll renderer จบภายในเวลาที่กำหนดและเก็บค่าที่มีรูปแบบ {tag} ได้'
}
finally {
    if ($null -ne $job) { Remove-Job -Job $job -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
}
