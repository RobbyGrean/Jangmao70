param(
    [string]$ExePath
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $root 'dist\Khet70\Khet70.exe'
}
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path $ExePath).Path)
$procurementRendererType = $assembly.GetType('Khet70.Khet70DocxRenderer', $true)
$findTags = $procurementRendererType.GetMethod('FindBusinessTags', [Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Static)
$procurementRenderer = $procurementRendererType.GetMethod('Render', [Reflection.BindingFlags]::Public -bor [Reflection.BindingFlags]::Static)
$payrollRenderer = $assembly.GetType('Khet70.Program', $true).GetMethod('RenderDocx', [Reflection.BindingFlags]::NonPublic -bor [Reflection.BindingFlags]::Static)
if ($null -eq $findTags -or $null -eq $procurementRenderer -or $null -eq $payrollRenderer) { throw 'ไม่พบ renderer ที่ต้องใช้ตรวจเอกสาร' }

Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
public static class Khet70FullRenderInvoker
{
    public static string[] FindTags(MethodInfo method, string path)
    {
        return ((IEnumerable<string>)method.Invoke(null, new object[] { path })).ToArray();
    }

    public static void Render(MethodInfo method, string sourcePath, string outputPath, Dictionary<string, string> values)
    {
        method.Invoke(null, new object[] { sourcePath, outputPath, values });
    }
}
'@

$templateRoot = Join-Path (Split-Path $ExePath -Parent) 'Template'
$templates = @(Get-ChildItem -LiteralPath $templateRoot -Filter '*.docx' -Recurse -File)
if ($templates.Count -ne 49) { throw "FAIL: พบ Template ใน dist $($templates.Count) ไฟล์ แต่คาดไว้ 49 ไฟล์" }

$work = Join-Path $env:TEMP ('Khet70-render-all-regression-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$created = 0
try {
    foreach ($template in $templates) {
        $tags = [Khet70FullRenderInvoker]::FindTags($findTags, $template.FullName)
        $values = New-Object 'System.Collections.Generic.Dictionary[string,string]'
        foreach ($tag in $tags) { $values[$tag] = 'QA' }

        $relative = $template.FullName.Substring($templateRoot.Length).TrimStart('\')
        $isPayroll = $relative.StartsWith('Payroll\', [StringComparison]::OrdinalIgnoreCase)
        $renderer = if ($isPayroll) { $payrollRenderer } else { $procurementRenderer }
        $outputPath = Join-Path $work ('output-' + $created.ToString('D2') + '.docx')
        [Khet70FullRenderInvoker]::Render($renderer, $template.FullName, $outputPath, $values)
        if (-not (Test-Path -LiteralPath $outputPath -PathType Leaf)) { throw "FAIL: ไม่ได้ output จาก $relative" }

        $remaining = [Khet70FullRenderInvoker]::FindTags($findTags, $outputPath)
        if ($remaining.Count -gt 0) { throw "FAIL: $relative ยังมีแท็กค้าง: $($remaining -join ', ')" }
        $created++
    }
    Write-Host "PASS: สร้างและตรวจแท็กเอกสารครบ $created/49 ไฟล์"
}
finally {
    if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
}
