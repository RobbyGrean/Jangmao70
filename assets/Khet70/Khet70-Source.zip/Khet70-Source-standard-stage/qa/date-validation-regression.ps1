param(
    [string]$ExePath
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $root 'dist\Khet70\Khet70.exe'
}
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path $ExePath).Path)
$formType = $assembly.GetType('Khet70.Program+MainForm', $true)
$parser = $formType.GetMethod('TryParseThaiDate', [Reflection.BindingFlags]::NonPublic -bor [Reflection.BindingFlags]::Static)
if ($null -eq $parser) { throw 'ไม่พบ date parser สำหรับทดสอบ' }

Add-Type -TypeDefinition @'
using System;
using System.Reflection;
public static class Khet70DateRegressionInvoker
{
    public static bool Parse(MethodInfo parser, string value)
    {
        var arguments = new object[] { value, DateTime.MinValue };
        return (bool)parser.Invoke(null, arguments);
    }

    public static bool Contract(MethodInfo validator, string day, string month, string year)
    {
        return (bool)validator.Invoke(null, new object[] { day, month, year });
    }
}
'@

$cases = @(
    @{ Value = '30/9/2569'; Expected = $true },
    @{ Value = '30 กันยายน 2569'; Expected = $true },
    @{ Value = '30 ก.ย. 2569'; Expected = $true },
    @{ Value = '31/2/2569'; Expected = $false },
    @{ Value = '31 กุมภาพันธ์ 2569'; Expected = $false },
    @{ Value = '31/4/2570'; Expected = $false }
)
foreach ($case in $cases) {
    $actual = [Khet70DateRegressionInvoker]::Parse($parser, $case.Value)
    if ($actual -ne $case.Expected) {
        throw "FAIL: วันที่ '$($case.Value)' ได้ผล $actual แต่คาดว่า $($case.Expected)"
    }
}

$procurementType = $assembly.GetType('Khet70.ProcurementModule', $true)
$contractValidator = $procurementType.GetMethod('IsValidContractDate', [Reflection.BindingFlags]::NonPublic -bor [Reflection.BindingFlags]::Static)
if ($null -eq $contractValidator) { throw 'ไม่พบ contract date validator สำหรับทดสอบ' }
$contractCases = @(
    @{ Day = '30'; Month = 'กันยายน'; Year = '2569'; Expected = $true },
    @{ Day = '31'; Month = 'กุมภาพันธ์'; Year = '2569'; Expected = $false },
    @{ Day = '31'; Month = 'เมษายน'; Year = '2570'; Expected = $false }
)
foreach ($case in $contractCases) {
    $actual = [Khet70DateRegressionInvoker]::Contract($contractValidator, $case.Day, $case.Month, $case.Year)
    if ($actual -ne $case.Expected) {
        throw "FAIL: วันทำสัญญา '$($case.Day) $($case.Month) $($case.Year)' ได้ผล $actual แต่คาดว่า $($case.Expected)"
    }
}
Write-Host 'PASS: date validation ปฏิเสธวันที่ไม่มีอยู่จริงและยอมรับวันที่ถูกต้อง'
