$ErrorActionPreference = 'Stop'

$root = (Resolve-Path $PSScriptRoot).Path
$dist = Join-Path $root 'dist\Khet70'
$release = Join-Path $root 'release\Khet70-Installer'
$legacy = Join-Path $root 'release\legacy'
$setup = Join-Path $release 'Khet70-Setup.exe'
$standardZip = Join-Path $root 'release\Khet70-Installer-standard.zip'
$iss = Join-Path $root 'Khet70-Setup.iss'

$iscc = (Get-Command 'iscc.exe' -ErrorAction SilentlyContinue).Source
if ([string]::IsNullOrWhiteSpace($iscc)) {
    foreach ($candidate in @(
        'C:\Program Files (x86)\Inno Setup 6\ISCC.exe',
        'C:\Program Files\Inno Setup 6\ISCC.exe',
        'C:\Users\MSI\AppData\Local\Programs\Inno Setup 6\ISCC.exe'
    )) {
        if (Test-Path -LiteralPath $candidate) {
            $iscc = $candidate
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($iscc)) { throw 'ไม่พบ Inno Setup Compiler (ISCC.exe)' }

foreach ($requiredLegacy in @(
    (Join-Path $legacy 'Khet70-Setup-legacy.exe'),
    (Join-Path $legacy 'Khet70-Installer-legacy.zip')
)) {
    if (-not (Test-Path -LiteralPath $requiredLegacy)) {
        throw "ไม่พบไฟล์ Legacy ที่ต้องเก็บรักษา: $requiredLegacy"
    }
}

& (Join-Path $root 'verify-manifest.ps1')
& (Join-Path $root 'build-exe-Khet70.ps1')
if (-not (Test-Path -LiteralPath (Join-Path $dist 'Khet70.exe'))) {
    throw 'Built executable is missing'
}
& (Join-Path $root 'qa\payroll-renderer-regression.ps1') -ExePath (Join-Path $dist 'Khet70.exe')
& (Join-Path $root 'qa\date-validation-regression.ps1') -ExePath (Join-Path $dist 'Khet70.exe')
& (Join-Path $root 'qa\render-all-regression.ps1') -ExePath (Join-Path $dist 'Khet70.exe')

$docxFiles = @(Get-ChildItem -LiteralPath (Join-Path $dist 'Template') -Filter '*.docx' -Recurse -File)
if ($docxFiles.Count -ne 49) {
    throw "Expected 49 packaged DOCX templates, found $($docxFiles.Count)."
}

New-Item -ItemType Directory -Path $release -Force | Out-Null
if (Test-Path -LiteralPath $setup) { Remove-Item -LiteralPath $setup -Force }
if (Test-Path -LiteralPath $standardZip) { Remove-Item -LiteralPath $standardZip -Force }

& $iscc "/O$release" $iss
if ($LASTEXITCODE -ne 0) { throw "Inno Setup compile failed with exit code $LASTEXITCODE" }
if (-not (Test-Path -LiteralPath $setup)) { throw 'Standard installer output is missing' }

Compress-Archive -LiteralPath $setup -DestinationPath $standardZip -Force
$hash = (Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash

Write-Host "Standard installer built: $setup"
Write-Host "Standard installer archive: $standardZip"
Write-Host "SHA256: $hash"

$sourceZip = Join-Path $root 'release\Khet70-Source-standard.zip'
$sourceStage = Join-Path $root 'release\Khet70-Source-standard-stage'
if (Test-Path -LiteralPath $sourceStage) { Remove-Item -LiteralPath $sourceStage -Recurse -Force }
New-Item -ItemType Directory -Path $sourceStage | Out-Null
$excludedSourceDirectories = @('.git', 'dist', 'release', 'qa')
Get-ChildItem -LiteralPath $root -Force |
    Where-Object { $excludedSourceDirectories -notcontains $_.Name } |
    ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $sourceStage -Recurse -Force }
$sourceQa = Join-Path $sourceStage 'qa'
New-Item -ItemType Directory -Path $sourceQa | Out-Null
Get-ChildItem -LiteralPath (Join-Path $root 'qa') -Filter '*.ps1' -File |
    ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $sourceQa -Force }
if (Test-Path -LiteralPath $sourceZip) { Remove-Item -LiteralPath $sourceZip -Force }
Compress-Archive -Path $sourceStage -DestinationPath $sourceZip -Force
Remove-Item -LiteralPath $sourceStage -Recurse -Force
Write-Host "Standard source archive: $sourceZip"
