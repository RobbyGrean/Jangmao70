# Khet70 → Jangmao70: รายงาน Handoff และคู่มือทำซ้ำระบบ

วันที่จัดทำ: 25 กันยายน 2569  
โครงการต้นทาง: Khet70  
โครงการปลายทาง: Jangmao70

เอกสารนี้เป็นรายงานสอนงาน ไม่ใช่เพียง changelog โดยอธิบายตั้งแต่การแทนไฟล์ Word, การวางไฟล์ 9. สัญญา, การแทนที่ TOR, การทำ route และ page mapping, การกำหนด tag contract, การรับข้อมูลจากฟอร์ม, การคำนวณเงิน, การ validate, การแทนแท็กใน DOCX, การทดสอบ, การ build installer รุ่นใหม่ และแนวทางนำไปใช้กับ Jangmao70

หลักที่ควรนำไปใช้กับ Jangmao70 คือสถาปัตยกรรมและวิธีคิด ไม่ใช่การคัดลอกค่าของ Khet70 แบบตรง ๆ เพราะตำแหน่ง อัตราเงินเดือน จำนวนหน้า และ workflow ของ Jangmao70 อาจต่างกัน

หลักคิดกลาง

1. Template เป็นข้อมูลที่เปลี่ยนได้ ไม่ควรฝังชื่อไฟล์และจำนวนหน้าทั้งหมดไว้ใน source code
2. UI รับข้อมูลเข้า model/record ก่อน ไม่ให้ renderer อ่าน control โดยตรง
3. ทุกค่าที่จะลง Word ต้องรวมผ่าน BuildValues เป็น dictionary กลาง
4. Tag ใน Word เป็น contract ระหว่าง template กับโปรแกรม
5. วันที่ เงิน และข้อมูลสำคัญต้อง normalize และ validate ก่อนสร้าง
6. ต้อง render และตรวจทุก template จริง ไม่ใช่ตรวจแค่ compile
7. Installer, template, config, source และ output ต้องมีขอบเขตชัดเจน
8. เปลี่ยน template ไม่เท่ากับเปลี่ยน business logic และเปลี่ยน business logic ไม่ควรแก้ด้วยการแก้ Word อย่างเดียว

---

## 1. สถานะปัจจุบันของ Khet70

### 1.1 สิ่งที่แก้และทำเสร็จแล้ว

- เปลี่ยนเอกสารกลางจาก 9. ใบสั่งจ้าง.docx เป็น 9. สัญญา.docx
- ไม่มี 9. ใบสั่งจ้างเป็นเอกสาร output ของ Procurement แล้ว
- แทนที่ชุด 3.TOR ด้วย TOR ล่าสุดของทั้ง 18 ตำแหน่ง
- ผูก TOR รายตำแหน่งด้วย route P01–P18
- ผูกจำนวนหน้า A/B ของ TOR ตามค่าที่ผู้ใช้ยืนยัน
- ผูกจำนวนหน้า C/D ของแนบท้ายใบเสนอราคาตามค่าที่ผู้ใช้ยืนยัน
- เพิ่มตำบลเขต อำเภอเขต จังหวัดเขต
- ทำ logic trim คำว่า ตำบล อำเภอ จังหวัด
- เพิ่ม mapping ถนนลูกจ้างผ่าน {ถนนลูกจ้าง}
- ใช้ชื่อกล่องกรอก “เลขที่สัญญา” แม้ tag เดิมในเอกสารยังเป็น {ใบสั่งจ้าง}
- เปลี่ยนวัน เดือน ปีทำสัญญาเป็น dropdown
- จำกัดปีทำสัญญาเป็น 2569 และ 2570
- เพิ่มปี 2570 ใน dropdown วันที่สั่งจ้างของ Payroll
- เพิ่มการตรวจวันที่ที่ไม่มีอยู่จริง เช่น 31 กุมภาพันธ์
- ใช้เงินเดือน 8,500, 9,000, 15,000 และ 18,000
- เพิ่มค่าเงินเดือนรวม 12 เดือนและข้อความภาษาไทย
- เพิ่มค่าเงินเดือนหารสามสิบและข้อความภาษาไทย
- บังคับให้เงินเดือนหารสามสิบแบบตัวเลขมีคำว่า “บาท”
- ให้ข้อความจำนวนเงินลงท้ายด้วย “บาทถ้วน”
- แก้ renderer ของ Payroll ไม่ให้เกิดลูปไม่จบเมื่อค่าที่ผู้ใช้กรอกมีหน้าตาเหมือนแท็ก
- เพิ่ม regression test ของ renderer, date validation และการสร้างเอกสารครบทุกไฟล์
- build installer มาตรฐาน
- ทำ installer ZIP มาตรฐาน
- ทำ source ZIP มาตรฐาน
- เก็บ installer รุ่นเดิมไว้ในโฟลเดอร์ legacy
- ติดตั้งรุ่นมาตรฐานทับ installation จริงเพื่อ smoke test
- ตรวจว่า EXE ที่ติดตั้งมี hash ตรงกับ EXE ที่ build
- ตรวจว่า uninstaller ของรุ่นมาตรฐานถูกสร้างขึ้น
- เปลี่ยนข้อความก่อนปิดโปรแกรมเป็นการถามว่าจะบันทึก Template ที่จัดทำค้างไว้หรือไม่

### 1.2 หลักฐานการตรวจล่าสุด

- Manifest ผ่าน
- Payroll templates 4 ไฟล์
- Procurement templates 45 ไฟล์
- Position routes 18 routes
- DOCX ที่ package รวม 49 ไฟล์
- สร้างและตรวจแท็กครบ 49/49 ไฟล์
- Payroll renderer กรณีค่าจริงเป็น {ชื่อลูกจ้าง} ผ่าน
- Date validation ผ่านทั้งวันส่งเบิกและวันทำสัญญา
- Installer compile ผ่าน
- ติดตั้งทับ installation จริงได้
- EXE ที่ติดตั้งมี hash ตรงกับ EXE ที่ build
- เปิดโปรแกรมหลังติดตั้งและปิดได้ตามปกติ

ข้อสรุปเชิง release: ฟังก์ชันหลักพร้อมใช้งานสำหรับ release ปัจจุบัน โดยยังมีความเสี่ยงที่ยอมรับไว้ 3 กลุ่ม คือ partial output, manual JSON และข้อมูล local แบบ plaintext

---

## 2. ลำดับการเปลี่ยน Template ที่ทำจริง

### 2.1 เปลี่ยน 9. ใบสั่งจ้าง เป็น 9. สัญญา

เดิมระบบใช้

~~~text
9. ใบสั่งจ้าง.docx
~~~

แต่ workflow จริงต้องใช้แบบสัญญา จึงนำไฟล์

~~~text
9. สัญญา.docx
~~~

เข้าไว้ที่

~~~text
Template\Procurement\9. สัญญา.docx
~~~

จากนั้นทำครบตามลำดับนี้

1. สำรอง Template เดิม
2. วาง 9. สัญญา.docx ในโฟลเดอร์ Procurement
3. เอา 9. ใบสั่งจ้าง.docx ออกจากชุดที่โปรแกรมใช้
4. แก้ centralDocuments ใน Config\Procurement\template_manifest.json
5. update SHA-256 ของไฟล์ใหม่
6. รัน verify-manifest.ps1
7. build dist ใหม่
8. render test ไฟล์ 9. สัญญา
9. build installer
10. ติดตั้งทับและทดลองสร้าง output

manifest ต้องมี

~~~text
id: 9. สัญญา
relativePath: 9. สัญญา.docx
~~~

และต้องไม่มีรายการ 9. ใบสั่งจ้างอีก

ผลลัพธ์

~~~text
8. ประกาศผู้ชนะ.docx
9. สัญญา.docx
~~~

ไม่มีใบสั่งจ้างเป็น output แล้ว

#### เลขที่สัญญา

UI label ใหม่คือ

~~~text
เลขที่สัญญา
~~~

แต่ tag ที่คงไว้เพื่อให้ template เดิมใช้งานได้คือ

~~~text
{ใบสั่งจ้าง}
~~~

สามชั้นจึงเป็น

~~~text
UI label: เลขที่สัญญา
model key: procurement.contractNumber
template tag: {ใบสั่งจ้าง}
~~~

BuildValues map

~~~text
{ใบสั่งจ้าง} ← source.Procurement.ContractNumber
~~~

ถ้า Jangmaoจะเปลี่ยนชื่อ tag ควรเปลี่ยน template, model mapping, validation, tag inventory และ test พร้อมกัน ห้ามเปลี่ยนเฉพาะ label

#### อากรแสตมป์

แบบสัญญาใหม่ไม่มีข้อความให้ลงจำนวนอากรในเอกสาร แต่โปรแกรมยังคำนวณ {บาทอากร} และแสดงใน UI เช่น

~~~text
เงินรวม 12 เดือน / อากรแสตมป์ที่ต้องติด
180,000 บาท / ติดอากรแสตมป์ 180 บาท
~~~

- {บาทอากร} ยังเป็น derived value ใน dictionary
- ใช้ได้หาก template ใดต้องการ
- ไม่ยัดข้อความอากรลงใน 9. สัญญาโดยอัตโนมัติ
- ผู้ใช้งานยังได้รับคำเตือนว่าต้องติดอากร
- ไม่ควร hard-code ข้อความอากรในแบบสัญญาที่ไม่มีช่องดังกล่าว

### 2.2 การแทนที่ 3.TOR

ต้นทาง runtime คือ

~~~text
Template\Procurement\3.TOR
~~~

มี TOR 18 ไฟล์ แต่ละไฟล์จับคู่กับ positionId ผ่าน manifest เช่น

~~~text
positionId: p01
tor: 3.TOR/3.1 TOR เจ้าหน้าที่ ICT.docx
~~~

ระบบไม่ควรเดาจากชื่อไฟล์อย่างเดียว เพราะชื่อไฟล์อาจเปลี่ยนได้ แต่ route ต้องยังชี้ไปไฟล์ที่ถูกต้อง

เมื่อนำ TOR ชุดใหม่เข้าโปรแกรม

1. สำรองชุดเดิม
2. copy TOR ใหม่เข้า 3.TOR
3. ตรวจว่าครบ 18 ไฟล์
4. ตรวจชื่อและเนื้อความ
5. ตรวจจำนวนหน้าหลัง Word จัดหน้าใหม่
6. แก้ path ถ้าชื่อไฟล์เปลี่ยน
7. แก้ torSha256
8. แก้ torPageCount
9. แก้ torPageCountText
10. รัน verifier
11. build
12. render test

ถ้าเพิ่มหรือลดข้อความใน TOR จำนวนหน้าอาจเปลี่ยน ต้อง scan ใหม่เสมอ

### 2.3 การแทนที่ 6.1 แนบท้ายใบเสนอราคา

โฟลเดอร์

~~~text
Template\Procurement\6.1 แนบท้ายใบเสนอราคา
~~~

มี 18 ไฟล์ และจับคู่กับตำแหน่งเดียวกับ TOR

ค่าที่ final แล้วคือทุกตำแหน่ง

~~~text
quotePageCount: 2
quotePageCountText: สอง
~~~

ดังนั้น

~~~text
{หน้าC} = 2
{หน้าD} = สอง
~~~

ถ้าแก้ Word แล้วเป็น 3 หน้า ต้องแก้ทั้ง 2 จุดเป็น 3 และ สามใน route นั้น

### 2.4 โฟลเดอร์สำเนาที่ไฮไลท์แท็ก

เครื่องมือ

~~~text
qa\highlight_template_tags.py
~~~

สร้างสำเนา Word และไฮไลท์ run ที่พบ tag โดยแก้ XML ภายใน DOCX อย่างระมัดระวัง

โฟลเดอร์สำเนา

~~~text
TemplateKhet70new
~~~

หลักการ

1. copy โฟลเดอร์ต้นทางไปปลายทางใหม่
2. เปิด DOCX เป็น ZIP
3. อ่าน word/document.xml, header และ footer
4. รวมข้อความของแต่ละ paragraph
5. หา pattern {ข้อความ}
6. หา run ที่ครอบแท็ก
7. เพิ่ม w:highlight val="green"
8. เขียน package กลับ
9. ไม่เขียนทับปลายทางที่มีอยู่แล้ว

TemplateKhet70new เป็นสำเนาช่วยแก้/ตรวจ ไม่ใช่ runtime source ปัจจุบันซึ่งยังใช้ Template หากนำไฟล์ที่ไฮไลท์ไปใช้จริง ต้องตรวจ layout, page count, header/footer และ hash ใหม่

---

## 3. โครงสร้างข้อมูลและลำดับการสร้างเอกสาร

~~~text
ผู้ใช้กรอกฟอร์ม
    ↓
Capture เข้า model/record
    ↓
Normalize
    ↓
Validate
    ↓
เลือก position และ route
    ↓
BuildValues สร้าง Dictionary แท็ก → ค่า
    ↓
เลือก Template จาก manifest
    ↓
Render DOCX
    ↓
ตรวจ unresolved tag
    ↓
บันทึก output
~~~

ไม่ควรให้ renderer อ่าน TextBox ทีละช่องหรือคำนวณเงินระหว่างแทนแท็ก เพราะจะทำให้เอกสารชุดเดียวกันใช้ค่าคนละชุดและทดสอบยาก

---

## 4. Tag contract ของ Khet70

### 4.1 กฎทั่วไป

แท็กเป็นข้อความ literal รูปแบบ

~~~text
{ชื่อแท็ก}
~~~

- วงเล็บต้องครบ
- ชื่อภาษาไทยต้องตรงทุกตัว
- ห้ามแอบใส่ช่องว่างใน tag
- เปลี่ยนชื่อ tag ต้องแก้ทั้ง template และ mapping
- renderer รองรับ tag ข้าม Word run
- ค่าจริงที่หน้าตาเหมือน tag ต้องไม่ทำให้เกิด loop
- tag ที่ไม่มีใน dictionary ต้องถูกตรวจพบ
- Procurement optional ที่ว่างใช้ .............
- Payroll address ที่ว่างใช้ ................................ เพื่อคง layout

### 4.2 ข้อมูลเขตและสำนักงาน

| Tag | Model source | Logic |
|---|---|---|
| {ชื่อโรงเรียน} | school.name | Khet70 ตั้งว่าง เพราะเป็น workflow สำนักงานเขต |
| {ชื่อโรงเรียนสอง} | school.secondName | ตั้งว่าง เพราะไม่ใช้สองโรงเรียน |
| {ชื่อเขต} | school.district | normalize เป็นชื่อสำนักงานเขตเต็ม |
| {ชื่อเขตย่อ} | school.districtShort | รับจากผู้ใช้ |
| {ตำบลเขต} | school.zoneSubdistrict | strip ตำบล |
| {อำเภอเขต} | school.zoneDistrict | strip อำเภอ |
| {จังหวัดเขต} | school.zoneProvince | strip จังหวัด |

ตัวอย่าง

~~~text
ตำบลบางเขน → บางเขน
อำเภอเมืองนนทบุรี → เมืองนนทบุรี
จังหวัดนนทบุรี → นนทบุรี
~~~

NormalizeDistrictName

1. trim หัวท้าย
2. รวม whitespace ซ้ำ
3. ถ้าเริ่มด้วย “สำนักงานเขตพื้นที่การศึกษา” ให้คงเดิม
4. ถ้าเริ่มด้วย “ประถมศึกษา” หรือ “มัธยมศึกษา” ให้เติม prefix หน่วยงาน
5. ถ้ากรอกชื่อสั้น ให้เติม “สำนักงานเขตพื้นที่การศึกษาประถมศึกษา”

ตัวอย่าง

~~~text
นนทบุรี
→ สำนักงานเขตพื้นที่การศึกษาประถมศึกษานนทบุรี

ประถมศึกษานนทบุรี
→ สำนักงานเขตพื้นที่การศึกษาประถมศึกษานนทบุรี
~~~

Jangmaoต้องตรวจ prefix จริงของหน่วยงานก่อน copy logic นี้

### 4.3 ผู้ลงนาม

ผู้อำนวยการ

~~~text
{คำนำหน้าผอ}
{ชื่อผอ}
{นามสกุลผอ}
~~~

เจ้าหน้าที่พัสดุ

~~~text
{คำนำหน้าพัสดุ}
{ชื่อพัสดุ}
{นามสกุลพัสดุ}
~~~

หัวหน้าเจ้าหน้าที่พัสดุ

~~~text
{คำนำหน้าหพัสดุ}
{ชื่อหพัสดุ}
{นามสกุลหพัสดุ}
~~~

ผู้อำนวยการกลุ่มการเงิน

~~~text
{คำนำหน้าผอกง}
{ชื่อผอกง}
{นามสกุลผอกง}
~~~

รองผู้อำนวยการเขต

~~~text
{คำนำหน้ารองเขต}
{ชื่อรองเขต}
{นามสกุลรองเขต}
~~~

### 4.4 กรรมการ TOR

กรรมการ A/B/C แต่ละรายมี

~~~text
{คำนำหน้าสเปคA}
{ชื่อสเปคA}
{นามสกุลสเปคA}
{ตำแหน่งสเปคA}

{คำนำหน้าสเปคB}
{ชื่อสเปคB}
{นามสกุลสเปคB}
{ตำแหน่งสเปคB}

{คำนำหน้าสเปคC}
{ชื่อสเปคC}
{นามสกุลสเปคC}
{ตำแหน่งสเปคC}
~~~

รูปแบบที่นำไปใช้ซ้ำได้

~~~text
for member in committee:
    suffix = A/B/C
    values["{คำนำหน้าสเปค" + suffix + "}"] = member.prefix
    values["{ชื่อสเปค" + suffix + "}"] = member.givenName
    values["{นามสกุลสเปค" + suffix + "}"] = member.surname
    values["{ตำแหน่งสเปค" + suffix + "}"] = member.position
~~~

### 4.5 ข้อมูลลูกจ้าง

ข้อมูลหลัก

~~~text
{คำนำหน้าลูกจ้าง}
{ชื่อลูกจ้าง}
{นามสกุลลูกจ้าง}
{เลขประจำตัว}
{ตำแหน่ง}
~~~

ชื่อ UI ของ {เลขประจำตัว} คือ “เลขประจำตัวประชาชน” และ Procurement ตรวจเป็นตัวเลข 13 หลัก

ข้อมูลส่วนตัว

~~~text
{สัญชาติ}
{เชื้อชาติ}
{ศาสนา}
{เกิดวันที่}
{เดือนเกิด}
{ปีเกิด}
{อายุลูกจ้าง}
~~~

ข้อมูลบัตร

~~~text
{ออกอำเภอ}
{ออกจังหวัด}
{วันที่ออกบัตร}
{เดือนออกบัตร}
{ปีออกบัตร}
{วันบัตรหมดอายุ}
{เดือนบัตรหมดอายุ}
{ปีบัตรหมดอายุ}
~~~

การศึกษา

~~~text
{สำเร็จการศึกษาระดับ}
{คุณวุฒิการศึกษา}
~~~

ที่อยู่

~~~text
{บ้านเลขที่ลูกจ้าง}
{ถนนลูกจ้าง}
{ตำบลลูกจ้าง}
{อำเภอลูกจ้าง}
{จังหวัดลูกจ้าง}
~~~

จุดสำคัญที่แก้เพิ่ม

~~~text
{ถนนลูกจ้าง} ← source.Employee.Road
~~~

ตำบล/อำเภอ/จังหวัดของลูกจ้างใช้ StripPrefix แบบเดียวกัน

~~~text
ตำบล... → ...
อำเภอ... → ...
จังหวัด... → ...
~~~

### 4.6 ตำแหน่ง

tag หลัก

~~~text
{ตำแหน่ง}
~~~

catalog อยู่ที่ Config\Procurement\position_catalog.json และมีอย่างน้อย id, dropdownLabel, label, teachingFlag, twoSchoolsFlag

dropdownLabel ใช้บน UI และ label ใช้ชื่อทางการในเอกสาร

### 4.7 เงินเดือน

tags

~~~text
{เงินเดือน}
{เงินเดือนTEXT}
{เงินรวม}
{เงินรวมTEXT}
{เงินเดือนหารสามสิบ}
{เงินเดือนหารสามสิบTEXT}
{บาทอากร}
~~~

ค่าปัจจุบัน

| เงินเดือน | เงินเดือนTEXT | เงินรวม | เงินรวมTEXT | หาร 30 | หาร 30 TEXT | อากร |
|---:|---|---:|---|---|---|---:|
| 8,500 | แปดพันห้าร้อยบาทถ้วน | 102,000 | หนึ่งแสนสองพันบาทถ้วน | 283 บาท | สองร้อยแปดสิบสามบาทถ้วน | 102 |
| 9,000 | เก้าพันบาทถ้วน | 108,000 | หนึ่งแสนแปดพันบาทถ้วน | 300 บาท | สามร้อยบาทถ้วน | 108 |
| 15,000 | หนึ่งหมื่นห้าพันบาทถ้วน | 180,000 | หนึ่งแสนแปดหมื่นบาทถ้วน | 500 บาท | ห้าร้อยบาทถ้วน | 180 |
| 18,000 | หนึ่งหมื่นแปดพันบาทถ้วน | 216,000 | สองแสนหนึ่งหมื่นหกพันบาทถ้วน | 600 บาท | หกร้อยบาทถ้วน | 216 |

สูตร

~~~text
เงินเดือน = ค่าที่เลือก
เงินเดือนTEXT = ThaiBahtText(เงินเดือน) และลงท้าย บาทถ้วน
เงินรวม = เงินเดือน × 12
เงินรวมTEXT = ThaiBahtText(เงินรวม) และลงท้าย บาทถ้วน
เงินเดือนหารสามสิบ = truncate(เงินเดือน / 30) + " บาท"
เงินเดือนหารสามสิบTEXT = ThaiBahtText(truncate(เงินเดือน / 30))
บาทอากร = truncate(เงินรวม / 1000)
~~~

ตัวอย่าง 8,500

~~~text
8,500 ÷ 30 = 283.333...
ผลที่ต้องใช้ = 283 บาท
TEXT = สองร้อยแปดสิบสามบาทถ้วน
~~~

config อยู่ที่ Config\salary_rates.json

ถ้า Jangmaoผูกเงินเดือนตายตัวกับตำแหน่ง ให้ใช้ positionId → salaryRateId หรือ positionId → salary แทนการ copy รายการเงินเดือน Khet70

### 4.8 หน้า A/B/C/D

~~~text
{หน้าA} = หน้า TOR แบบตัวเลข
{หน้าB} = หน้า TOR เป็นข้อความไทย
{หน้าC} = หน้า quote/แนบท้ายแบบตัวเลข
{หน้าD} = หน้า quote/แนบท้ายเป็นข้อความไทย
~~~

ค่าปัจจุบัน

| Position | A/B | C/D |
|---|---|---|
| P01 | 4 / สี่ | 2 / สอง |
| P02 | 5 / ห้า | 2 / สอง |
| P03 | 5 / ห้า | 2 / สอง |
| P04 | 4 / สี่ | 2 / สอง |
| P05 | 5 / ห้า | 2 / สอง |
| P06 | 4 / สี่ | 2 / สอง |
| P07 | 5 / ห้า | 2 / สอง |
| P08 | 4 / สี่ | 2 / สอง |
| P09 | 4 / สี่ | 2 / สอง |
| P10 | 5 / ห้า | 2 / สอง |
| P11 | 4 / สี่ | 2 / สอง |
| P12 | 4 / สี่ | 2 / สอง |
| P13 | 4 / สี่ | 2 / สอง |
| P14 | 4 / สี่ | 2 / สอง |
| P15 | 4 / สี่ | 2 / สอง |
| P16 | 4 / สี่ | 2 / สอง |
| P17 | 4 / สี่ | 2 / สอง |
| P18 | 4 / สี่ | 2 / สอง |

สรุป

~~~text
4 / สี่: P01, P04, P06, P08, P09, P11–P18
5 / ห้า: P02, P03, P05, P07, P10
C/D ทุกตำแหน่ง: 2 / สอง
~~~

ทั้งหมดเก็บใน route ของ Config\Procurement\template_manifest.json ห้ามทำ if/else จำนวนหน้า 18 ชุดใน renderer

### 4.9 สัญญา ธนาคาร และคำสั่ง

สัญญา

~~~text
{ใบสั่งจ้าง} ← เลขที่สัญญา
{วันทำสัญญา}
{เดือนทำสัญญา}
{ปีทำสัญญา}
~~~

ธนาคาร

~~~text
{ธนาคาร}
{สาขาธนาคาร}
{ชื่อบัญชีธนาคาร}
{เลขบัญชี}
~~~

คำสั่ง

~~~text
{คำสั่งสเปค}
~~~

---

## 5. Logic วันที่

### 5.1 Procurement: วันทำสัญญา

ใช้ dropdown 3 ช่อง

~~~text
วันทำสัญญา
เดือนทำสัญญา
ปีทำสัญญา
~~~

ปีที่เปิดให้เลือก

~~~text
2569
2570
~~~

เมื่อเลือกครบจะรวมค่า เช่น

~~~text
30 กันยายน 2569
~~~

ก่อนสร้างจะเรียก IsValidContractDate โดยแปลงปี พ.ศ. เป็น ค.ศ. แล้วให้ DateTime ตรวจ

ผ่าน

~~~text
30 กันยายน 2569
~~~

ไม่ผ่าน

~~~text
31 กุมภาพันธ์ 2569
31 เมษายน 2570
~~~

### 5.2 Payroll: วันที่สั่งจ้าง

วันที่สั่งจ้างใช้ dropdown วัน เดือน ปี และปีมี 2569/2570

ค่าเต็มลง tag

~~~text
{วันที่สั่งจ้าง}
~~~

ส่วน {ปีใบสั่งจ้าง} ใน Payroll เป็นค่าที่คำนวณจากเดือนส่งมอบและปีงบประมาณ ไม่ใช่ปีทำสัญญาของ Procurement

### 5.3 Payroll: วันที่ส่งเบิก

tags

~~~text
{วันที่ส่งเบิก}
{เดือนที่ส่งมอบ}
{ย่อเดือนที่ส่งมอบ}
{ปีงบประมาณ}
~~~

{วันที่ส่งเบิก}

- ถ้ามีในฐานข้อมูลตาม fiscal month/year ให้เติมอัตโนมัติและ lock
- ถ้าไม่มี ให้กรอกเอง
- รับ 30/9/2569
- รับ 30 กันยายน 2569
- รับ 30 ก.ย. 2569
- ตรวจวันจริง
- ผิดแล้วหยุดสร้างและแจ้งเตือน

สรุปโมดูล

| Tag | Module |
|---|---|
| {วันทำสัญญา} | Procurement |
| {เดือนทำสัญญา} | Procurement |
| {ปีทำสัญญา} | Procurement |
| {วันที่สั่งจ้าง} | Payroll |
| {วันที่ส่งเบิก} | Payroll |
| {เดือนที่ส่งมอบ} | Payroll |
| {ย่อเดือนที่ส่งมอบ} | Payroll |
| {ปีงบประมาณ} | Payroll |

---

## 6. UI label, model key และ template tag

ไม่จำเป็นต้องชื่อเดียวกัน

| UI | Model key | Template tag |
|---|---|---|
| เลขที่สัญญา | procurement.contractNumber | {ใบสั่งจ้าง} |
| เลขประจำตัวประชาชน | employee.nationalId | {เลขประจำตัว} |
| ชื่อเขตพื้นที่การศึกษา | school.district | {ชื่อเขต} |
| ตำบลเขต | school.zoneSubdistrict | {ตำบลเขต} |
| เงินเดือนTEXT | derived salary value | {เงินเดือนTEXT} |

ข้อดี

- UI ใช้ภาษาที่ผู้ใช้เข้าใจ
- model ใช้ชื่อเชิงเทคนิค
- tag รักษาความเข้ากันได้กับเอกสาร

ควรมี field metadata เช่น

~~~json
{
  "modelKey": "employee.nationalId",
  "tag": "{เลขประจำตัว}",
  "label": "เลขประจำตัวประชาชน",
  "type": "text",
  "required": true,
  "normalizer": "trim"
}
~~~

---

## 7. Required, optional และ placeholder

### Procurement required ที่สำคัญ

- ชื่อเขต
- ชื่อเขตย่อ
- ตำบลเขต
- อำเภอเขต
- จังหวัดเขต
- ผู้ลงนาม
- กรรมการ
- ลูกจ้าง
- เลขประจำตัวประชาชน
- ตำแหน่ง
- เงินเดือน
- เลขที่สัญญา
- วัน เดือน ปีทำสัญญา
- ธนาคาร
- สาขา
- ชื่อบัญชี
- เลขบัญชี
- route/page metadata
- เอกสารที่เลือก

### Procurement optional

- บ้านเลขที่ลูกจ้าง
- ถนนลูกจ้าง
- ตำบลลูกจ้าง
- อำเภอลูกจ้าง
- จังหวัดลูกจ้าง
- หัวหน้าการเงิน

ค่าว่าง optional ใน Procurement ใช้

~~~text
.............
~~~

### Payroll optional address

ใช้จุดยาว

~~~text
................................
~~~

การตัดสินใจว่า required/optional ต้องอยู่ใน field metadata/validation ไม่ควรปล่อยให้ renderer เดา

---

## 8. Renderer DOCX

### 8.1 DOCX เป็น ZIP/XML

ส่วนที่เกี่ยวกับข้อความมักอยู่ใน

~~~text
word/document.xml
word/header1.xml
word/footer1.xml
~~~

Word อาจแบ่ง tag เดียวข้ามหลาย run

~~~text
run 1: {เงิน
run 2: เดือน}
~~~

ดังนั้นไม่ควรใช้ string.Replace บน bytes ของ DOCX ทั้งไฟล์

### 8.2 ขั้นตอน renderer ของ Khet70

1. เปิด DOCX เป็น ZipArchive
2. คัดลอกทุก entry ไป output
3. แก้เฉพาะ document/header/footer XML
4. parse XML
5. วน paragraph
6. รวม direct w:t
7. หา tag ด้วย regex
8. หา node span ที่ tag คร่อม
9. รักษา prefix/suffix
10. ล้าง node ที่ถูกคร่อมถัดไป
11. ใส่ temporary token
12. ตรวจ unresolved tag
13. คืน token เป็นค่าจริง
14. เขียน XML กลับ
15. scan output รอบสุดท้าย

### 8.3 Token safety

ถ้าค่าที่ผู้ใช้กรอกคือ

~~~text
{ชื่อลูกจ้าง}
~~~

และ renderer ใส่ค่านี้กลับทันทีใน loop จะมองเป็น tag ใหม่และอาจวนไม่จบ

จึงใช้ token เช่น

~~~text
\uE000DOCUMENTKhet70<index>\uE001
~~~

ลำดับ

~~~text
template tag → token
ตรวจ tag ที่เหลือจาก template
token → user value
~~~

Payroll renderer ถูกแก้ให้ใช้แนวคิดเดียวกัน และมี regression test โดยตรง

### 8.4 unresolved tag

ถ้าพบ tag ที่ไม่อยู่ใน dictionary เช่น

~~~text
{แท็กใหม่ที่ยังไม่ map}
~~~

ต้องหยุดหรือแจ้ง error อย่างเห็นได้ชัด ไม่ควรส่งเอกสารที่ยังมี tag ค้าง

### 8.5 Partial output

ปัจจุบันสร้างหลายไฟล์ทีละไฟล์ ถ้าไฟล์ที่ 7 ล้มเหลว ไฟล์ 1–6 อาจยังอยู่

renderer ลบ output ของไฟล์ที่ตัวเองล้มเหลว แต่ยังไม่ได้ rollback ทั้ง batch

แนวทางแก้ในอนาคต

~~~text
สร้างใน temporary batch folder
→ render และตรวจทุกไฟล์
→ ผ่านทั้งหมดแล้วค่อยย้ายเข้า output จริง
~~~

หรือเก็บ created list แล้วลบทั้งหมดเมื่อ batch fail

ปัจจุบันถือเป็น reliability improvement เพราะ template ปัจจุบัน render ผ่าน 49/49

---

## 9. Procurement flow

### 9.1 Capture

อ่าน control เข้า WorkingRecord ซึ่งมี

~~~text
School
Employee
Procurement
Committee[]
~~~

renderer ไม่อ่าน control โดยตรง

### 9.2 NormalizeRecord

ทำอย่างน้อย

- trim contract number/date
- trim bank fields
- trim national ID
- normalize district
- trim zone address
- ตั้ง flag teaching/two schools ตาม scope Khet70
- ล้างชื่อโรงเรียนที่ไม่ได้ใช้

### 9.3 ValidateRecord

หยุดก่อน render ถ้า

- national ID ไม่ใช่ 13 หลัก
- position ไม่มีใน catalog
- salary resolve ไม่ได้
- contract date ผิด
- route ไม่มี
- page count ไม่ครบทั้ง numeric/text
- committee ไม่ครบ
- selected document ไม่มี
- ข้อมูลจำเป็นอื่นไม่ครบ

### 9.4 Resolve route

~~~text
positionId p01
→ route-p01
→ TOR p01
→ quote p01
→ A/B/C/D p01
~~~

Khet70 ตั้ง hasTeaching และ worksAtTwoSchools เป็น false ทั้งหมด เพราะไม่อยู่ใน scope รุ่นนี้ Jangmaoต้องตรวจ domain ของตัวเอง

### 9.5 BuildValues

ใช้ dictionary กลางชุดเดียวกับเอกสารทุกใบของ record เดียวกัน

~~~text
values["{ชื่อเขต}"] = ...
values["{ชื่อลูกจ้าง}"] = ...
values["{เงินเดือน}"] = ...
values["{หน้าA}"] = ...
values["{ใบสั่งจ้าง}"] = ...
~~~

### 9.6 GenerateDocuments

1. CaptureFromControls
2. clone record
3. NormalizeRecord
4. ValidateRecord
5. หา route
6. BuildValues
7. resolve path ใต้ template root
8. สร้างชื่อ output ที่ safe
9. render ตามเอกสารที่เลือก
10. ตรวจ tag ค้าง
11. แจ้งจำนวนไฟล์

path ถูก resolve ให้อยู่ใต้ template root เพื่อป้องกัน path traversal

---

## 10. Payroll flow

### 10.1 งวดส่งมอบ

เมื่อเลือกเดือน/ปี

1. หาเดือนเต็ม
2. หาเดือนย่อ
3. คำนวณงวด
4. หา pay date จากฐานข้อมูล
5. มีค่าให้เติมและ lock
6. ไม่มีค่าให้กรอก
7. คำนวณปีใบสั่งจ้างจาก fiscal year

### 10.2 NormalizeValues

- alias {คำนำหน้าชื่อ} จาก {คำนำหน้าลูกจ้าง}
- alias {กรรมการ B} จาก {กรรมการB}
- alias {กรรมการ C} จาก {กรรมการC}
- ตั้ง {ปีงบประมาณ} จาก {ปีใบสั่งจ้าง}
- เติมเงินเดือนTEXT
- เติมเงินรวม
- เติมเงินรวมTEXT
- เติมบาทอากร
- เติม placeholder address
- normalize district
- normalize วันที่สั่งจ้าง

### 10.3 Payroll tag ตามเอกสาร

3. ใบส่งมอบงาน

~~~text
{ชื่อเขต}
{วันที่ส่งเบิก}
{ย่อเดือนที่ส่งมอบ}
{ปีงบประมาณ}
{เดือนที่ส่งมอบ}
{คำนำหน้าลูกจ้าง}
{ชื่อลูกจ้าง}
{นามสกุลลูกจ้าง}
{ตำแหน่ง}
{ใบสั่งจ้าง}
{วันที่สั่งจ้าง}
{เงินเดือน}
{เงินเดือนTEXT}
{คำนำหน้าผอ}
{ชื่อผอ}
{นามสกุลผอ}
{ชื่อเขตย่อ}
{คำนำหน้าพัสดุ}
{ชื่อพัสดุ}
{นามสกุลพัสดุ}
~~~

4. ใบตรวจรับ

~~~text
{ชื่อเขต}
{วันที่ส่งเบิก}
{ตำแหน่ง}
{คำนำหน้าชื่อ}
{ชื่อลูกจ้าง}
{นามสกุลลูกจ้าง}
{ใบสั่งจ้าง}
{วันที่สั่งจ้าง}
{ย่อเดือนที่ส่งมอบ}
{ปีงบประมาณ}
{เงินเดือน}
{เงินเดือนTEXT}
{กรรมการA}
{กรรมการB}
{กรรมการC}
~~~

5. บันทึกอนุมัติเบิกจ่าย

~~~text
{ชื่อเขต}
{วันที่ส่งเบิก}
{ตำแหน่ง}
{คำนำหน้าชื่อ}
{ชื่อลูกจ้าง}
{นามสกุลลูกจ้าง}
{เงินเดือน}
{เงินเดือนTEXT}
{ชื่อพัสดุ}
{นามสกุลพัสดุ}
{ชื่อหพัสดุ}
{นามสกุลหพัสดุ}
{ชื่อการเงิน}
{นามสกุลการเงิน}
{โซนหัวหน้าการเงิน}
{หัวหน้าการเงิน}
{คำนำหน้าผอ}
{ชื่อผอ}
{นามสกุลผอ}
{ชื่อเขตย่อ}
~~~

8. ใบสำคัญรับเงิน

~~~text
{ชื่อเขต}
{คำนำหน้าลูกจ้าง}
{ชื่อลูกจ้าง}
{นามสกุลลูกจ้าง}
{บ้านเลขที่ลูกจ้าง}
{ถนนลูกจ้าง}
{ตำบลลูกจ้าง}
{อำเภอลูกจ้าง}
{จังหวัดลูกจ้าง}
{ตำแหน่ง}
{เงินเดือน}
{เดือนที่ส่งมอบ}
{เงินเดือนTEXT}
{คำนำหน้าผอกง}
{ชื่อผอกง}
{นามสกุลผอกง}
{ชื่อเขตย่อ}
~~~

---

## 11. ชื่อ tag ที่ห้ามสับสน

### {เงินหาร30} กับ {เงินเดือนหารสามสิบ}

Khet70 ใช้

~~~text
{เงินเดือนหารสามสิบ}
{เงินเดือนหารสามสิบTEXT}
~~~

ถ้า Jangmaoมี {เงินหาร30} ให้ทำ alias หรือเปลี่ยน template แต่ต้องนิยามให้ชัดว่าหารฐานใด

### {ปีใบสั่งจ้าง} กับ {ปีทำสัญญา}

- {ปีทำสัญญา}: Procurement, user เลือก
- {ปีใบสั่งจ้าง}: Payroll, derived จาก fiscal year

### {ใบสั่งจ้าง} กับ “เลขที่สัญญา”

ค่าเดียวกันใน Khet70 แต่ UI กับ tag ต่างชื่อเพื่อความเข้ากันได้

### tag วันที่ Payroll

~~~text
{วันที่ส่งเบิก}
{เดือนที่ส่งมอบ}
{ย่อเดือนที่ส่งมอบ}
{ปีงบประมาณ}
~~~

ไม่ใช่ tag ของแบบสัญญา Procurement โดยอัตโนมัติ

---

## 12. ไฟล์ source และหน้าที่

| ไฟล์ | หน้าที่ |
|---|---|
| Khet70App.cs | Payroll UI, date logic, derived salary, Payroll renderer |
| Modules\Procurement\ProcurementModule.cs | Procurement UI, model, validation, BuildValues, route |
| Shared\DocxRenderer.cs | Procurement renderer และ tag scan |
| Khet70Shell.cs | รวม module และ close/save flow |
| Shared\Khet70Core.cs | path/runtime/domain types |
| Shared\Khet70Config.cs | โหลด config/manifest |
| Shared\TemplateTransfer.cs | โอนข้อมูล Payroll/Procurement |
| Config\Procurement\position_catalog.json | 18 ตำแหน่ง |
| Config\Procurement\template_manifest.json | central docs, route, path, hash, pages |
| Config\Payroll\template_manifest.json | Payroll docs |
| Config\Payroll\template_tags.json | Payroll tags |
| Config\salary_rates.json | salary options/derived values |
| Config\app_identity.json | identity และ storage roots |
| Template\Procurement | production template Procurement |
| Template\Payroll | production template Payroll |
| qa\payroll-renderer-regression.ps1 | literal tag value test |
| qa\date-validation-regression.ps1 | valid/invalid date test |
| qa\render-all-regression.ps1 | render ทั้ง 49 |
| verify-manifest.ps1 | path/hash/count verifier |
| build-exe-Khet70.ps1 | compile EXE/package dist |
| build-installer-standard-Khet70.ps1 | standard build, QA, installer, source ZIP |
| Khet70-Setup.iss | standard Inno Setup |
| build-installer-Khet70.ps1 | legacy pipeline |
| Khet70Installer.cs | legacy custom installer |
| Khet70Uninstaller.cs | legacy custom uninstaller |

---

## 13. Manifest เป็น source of truth

ไฟล์หลัก

~~~text
Config\Procurement\template_manifest.json
~~~

centralDocuments ปัจจุบันมี

~~~text
1.ขอจ้างต่อเนื่อง 630.docx
2.1 ขอตั้งกกTOR.docx
2.2 คำสั่งTOR.docx
4.รายงานผล TOR.docx
5. รายงานขอจ้าง.docx
6. ใบเสนอราคา.docx
7. รายงานผลพิจารณา.docx
8. ประกาศผู้ชนะ.docx
9. สัญญา.docx
~~~

route ควรมี

~~~text
id
positionId
hasTeaching
worksAtTwoSchools
tor
quote
torSha256
quoteSha256
torPageCount
torPageCountText
quotePageCount
quotePageCountText
~~~

hash มีไว้ยืนยันว่าไฟล์ที่ตรวจจริงตรงกับไฟล์ที่ package

verify-manifest ตรวจ

- path เป็น relative
- path ไม่หลุด root
- ไฟล์มีจริง
- SHA-256 ตรง
- route id ไม่ซ้ำ
- document path ไม่ซ้ำ
- จำนวน DOCX จริงตรง manifest

---

## 14. วิธีตรวจ template ก่อน release

### ชั้นที่ 1: ไฟล์

- ครบหรือไม่
- ชื่อถูกหรือไม่
- เปิด Word ได้หรือไม่
- ไม่มีไฟล์เก่าค้าง
- ไม่เผลอใช้สำเนาผิดโฟลเดอร์

### ชั้นที่ 2: เนื้อความ

- ข้อ 6.1.2 เหมือนตามที่ตั้งใจหรือไม่
- ข้อ 7 ใช้ {เงินเดือน} ครบทั้ง 12 งวดหรือไม่
- หัวข้อข้อ 8 เหมือนหรือไม่
- เนื้อหาข้อ 8 เหมือนหรือไม่
- ความต่างที่เหลือเป็น fixed text/เลขรายการที่ตั้งใจหรือไม่

### ชั้นที่ 3: Tag

- เปิด/ปิดวงเล็บครบ
- สะกดเหมือนกัน
- ไม่มี tag ใหม่ที่ยังไม่ map
- ไม่มี tag ที่ source เลิกใช้แต่ Word ยังมี
- header/footer ก็ต้องตรวจ

### ชั้นที่ 4: Pagination

- TOR แต่ละตำแหน่งกี่หน้า
- 6.1 แต่ละตำแหน่งกี่หน้า
- numeric/text ตรงกัน
- แก้ข้อความแล้ว scan ใหม่

ความต่างแบบ manual ที่ผลลัพธ์เท่ากันไม่จำเป็นต้องทำ logic แยก แต่ต้องแน่ใจว่าไม่กระทบความหมายหรือข้อกฎหมาย

---

## 15. Build และ QA

### 15.1 Build EXE

build-exe-Khet70.ps1

1. compile C#
2. สร้าง dist\Khet70\Khet70.exe
3. copy config
4. copy Template
5. copy Template ซ้ำไป Defaults\Template

Defaults ใช้สำหรับคืน template ตั้งต้น

### 15.2 QA ใน standard pipeline

build-installer-standard-Khet70.ps1 ทำตามลำดับ

1. verify manifest
2. build EXE
3. ตรวจ DOCX ใน dist ครบ 49
4. payroll renderer regression
5. date validation regression
6. full render regression
7. compile installer
8. ทำ installer EXE
9. ทำ installer ZIP
10. ทำ source ZIP
11. รักษา legacy artifacts

### 15.3 Full render regression

- enumerate ทุก DOCX
- อ่าน tag
- เติมค่า QA
- เลือก renderer ตาม module
- สร้าง output
- ตรวจ output มีจริง
- สแกน tag ที่เหลือ
- ต้องผ่าน 49/49

---

## 16. ทำไมต้องจัดทำ Installer แบบใหม่

การทำ installer ใหม่ไม่ได้เกิดเพราะแค่เปลี่ยนชื่อไฟล์หรือเปลี่ยน destination แต่เกิดจากปัญหาเชิงพฤติกรรมของ installer เดิมและความต้องการ upgrade ที่ชัดขึ้น

### 16.1 ปัญหาของ installer เดิม

Installer เดิมเป็น custom self-extracting installer ที่เขียน C# เอง มีลักษณะสำคัญ

1. ฝัง Payload ZIP ไว้ใน EXE
2. แตก Payload ไป temporary folder ตอนติดตั้ง
3. copy ไฟล์จาก temporary folder ไป install root
4. มี custom logic ปิดโปรแกรมที่กำลังรัน
5. มี custom shortcut
6. มี custom uninstaller
7. custom uninstaller เรียก command ลบ install root ภายหลังเพื่อให้ลบตัวเองได้

รูปแบบนี้ทำงานได้ แต่มีความเสี่ยง/ข้อเสีย

- พฤติกรรมฝัง ZIP และแตกไฟล์ลง Temp คล้ายพฤติกรรมของ malware loader
- custom EXE ที่ compile ใหม่และไม่มี reputation อาจถูก Defender จัดเป็น PUA เช่น Contebrew
- การลบตัวเองต้องใช้ process/command ช่วย และทำให้ security scanner สนใจ
- flow backup ก่อน upgrade ไม่ชัดเท่า installer framework มาตรฐาน
- ต้องเขียนและดูแล logic copy, shortcut, close process และ cleanup เอง
- หากมีไฟล์เก่าจากรุ่นก่อนค้าง ต้องเขียน cleanup เอง
- ขอบเขตของ uninstaller ต้องพิสูจน์ด้วย custom guard ของเราเอง
- ผู้ใช้เห็นพฤติกรรมเป็นไฟล์หาย/ถูก quarantine ทั้ง installer และ installed EXE เมื่อ Defender แจ้งเตือน

ปัญหาที่เกิดขึ้นจริงในช่วงพัฒนา คือ Defender ตรวจพบ installer/EXE เป็น

~~~text
Program:Win32/Contebrew.A!ml
~~~

และ quarantine ทั้ง installer, Khet70.exe และ shortcut ที่เกี่ยวข้อง ไม่ได้แปลว่า source code เป็น malware แต่แปลว่ารูปแบบ package/พฤติกรรมมีความคล้ายกับโปรแกรมที่ระบบไม่ไว้ใจ

การเปลี่ยน destination folder อย่างเดียวไม่แก้ต้นเหตุ ถ้ายังใช้ embedded Payload, self-extracting behavior และ self-delete แบบเดิม

### 16.2 เป้าหมายของ standard installer

standard installer จึงจัดทำขึ้นเพื่อ

- ใช้ installer framework มาตรฐาน
- package จาก dist ที่ผ่าน QA
- ลด custom extraction code
- ทำ destination ให้คาดเดาได้
- backup template ก่อน upgrade
- cleanup ไฟล์เก่าแบบ explicit
- สร้าง uninstaller ตามระบบ installer
- แยก standard artifact ออกจาก legacy artifact
- ทำให้ตรวจสอบ/ส่ง report ให้ Defender ได้ง่ายขึ้น

การใช้ Inno Setup ไม่ได้ทำให้โปรแกรมปลอดภัยโดยอัตโนมัติ แต่ลด custom behavior ที่ไม่จำเป็นและทำให้ขอบเขตการติดตั้งชัดเจนกว่าเดิม

### 16.3 สิ่งที่ standard installer รับเข้า

standard installer ไม่ควร build จากไฟล์ Word ที่ยังไม่ test โดยตรง แต่ควรรับจาก dist ที่ผ่านขั้นตอนนี้

~~~text
source
  ↓
build EXE + copy Config + Template
  ↓
dist\Khet70
  ↓
verify + render regression
  ↓
Inno Setup package
  ↓
Khet70-Setup.exe
~~~

สิ่งที่ทดสอบจึงเป็นสิ่งเดียวกับที่ผู้ใช้ได้รับ

### 16.4 Destination และโครงสร้าง

standard ติดตั้งที่

~~~text
%LOCALAPPDATA%\Khet70
~~~

เหตุผล

- ไม่ต้องขอ administrator
- เป็นพื้นที่ของ user ปัจจุบัน
- แยกจาก source workspace
- ไม่ต้องเขียน Program Files
- แยก Data/Output/Template ได้

หลังติดตั้งควรมี

~~~text
%LOCALAPPDATA%\Khet70\
    Khet70.exe
    Config\
    Template\
    Defaults\Template\
    Data\
    Output\เงินเดือน\
    Output\เอกสารจัดจ้าง\
    unins000.exe
~~~

### 16.5 ลำดับการติดตั้งทับ

1. ปิด Khet70 ที่กำลังรัน หรือถามให้ผู้ใช้ปิด
2. backup Template เดิม
3. copy EXE ใหม่
4. copy Config ใหม่
5. copy production Template ใหม่
6. copy Defaults ใหม่
7. สร้าง Data และ Output
8. สร้าง Desktop shortcut
9. สร้าง Start Menu shortcut
10. ลงทะเบียน uninstaller
11. ถามว่าจะเปิดโปรแกรมหรือไม่

### 16.6 Backup ก่อน upgrade

backup อยู่ที่

~~~text
%LOCALAPPDATA%\Khet70\Data\TemplateBackups\Installer-YYYYMMDD-HHMMSS
~~~

ควรสำรอง Template ทั้งชุด ไม่ใช่เฉพาะ 9 เพราะ user อาจแก้ไฟล์อื่นไว้

### 16.7 Cleanup ชื่อไฟล์เก่า

เมื่อเปลี่ยน

~~~text
9. ใบสั่งจ้าง.docx
→ 9. สัญญา.docx
~~~

ต้อง cleanup path เก่าแบบเจาะจง

~~~text
Template\Procurement\9. ใบสั่งจ้าง.docx
Defaults\Template\Procurement\9. ใบสั่งจ้าง.docx
~~~

ห้ามลบทั้ง Template หรือใช้ wildcard กว้าง

### 16.8 Standard กับ Legacy

| เรื่อง | Standard รุ่นใหม่ | Legacy รุ่นเดิม |
|---|---|---|
| ตัว package | Inno Setup | C# custom installer |
| source | dist หลัง QA | Payload ZIP ใน custom EXE |
| destination | %LOCALAPPDATA%\Khet70 | %LOCALAPPDATA%\Khet70 |
| uninstaller | Inno unins000.exe | custom Uninstall Khet70.exe |
| เป้าหมาย | release ปัจจุบัน | rollback/อ้างอิง |
| ควรใช้ release ใหม่ | ใช่ | ไม่ใช่ |

### 16.9 การจำกัดขอบเขต

standard installer ควรแตะเฉพาะ

~~~text
%LOCALAPPDATA%\Khet70
Desktop shortcut ที่ target Khet70
Start Menu shortcut ที่ target Khet70
~~~

ไม่ควรแตะ source workspace, user documents, drive อื่น, output นอก install root หรือ shortcut ของโปรแกรมอื่น

### 16.10 Uninstaller

รุ่นมาตรฐานใช้ uninstaller ของ Inno Setup และผูกกับ install root รุ่นมาตรฐาน ส่วน legacy custom uninstaller มี behavior ต่างกันและสามารถลบ install root ของ legacy รวม Data, Template และ Output ภายใน root นั้น

ดังนั้นต้องติดป้าย legacy ให้ชัด และอย่าใช้ legacy uninstaller หากต้องการเก็บข้อมูล user ไว้

### 16.11 Defender false positive

แนวทางลดความเสี่ยง

- ใช้ Inno Setup สำหรับ standard
- package จาก dist ที่ตรวจแล้ว
- เก็บ SHA-256
- ไม่ใช้ obfuscation
- ไม่ใช้ delete wildcard กว้าง
- แยก legacy ที่เคยถูก detect
- ส่ง sample ให้ Microsoft ถ้าถูก detect
- release note ต้องบอกว่าไฟล์ใดเป็น standard/legacy

การเปลี่ยน destination อย่างเดียวไม่แก้ Contebrew ถ้าพฤติกรรม embedded payload และ self-delete ยังอยู่

### 16.12 ลำดับสร้าง installer ใหม่สำหรับ Jangmao

~~~text
1. Freeze templates
2. Freeze tag inventory
3. Update manifest/hash/page count
4. Build EXE
5. Verify manifest
6. Render every template
7. Scan unresolved tags
8. Test clean install
9. Test upgrade over previous version
10. Test backup Template
11. Test old-file cleanup
12. Test launch/output
13. Test uninstaller scope
14. Hash installer/source ZIP
15. Archive legacy separately
16. Release
~~~

### 16.13 Artifact ที่ควรส่งผู้ใช้

~~~text
Jangmao70-Setup.exe
Jangmao70-Installer-standard.zip
Jangmao70-Source-standard.zip
CHECKSUMS.txt หรือ release note ที่มี SHA-256
คู่มือ/รายงาน handoff
~~~

ไม่ควรส่ง Payload ZIP ให้ผู้ใช้ทั่วไป ถ้า Setup EXE ฝัง payload และติดตั้งให้แล้ว

---

## 17. ข้อความก่อนออกจากโปรแกรม

ข้อความปัจจุบัน

~~~text
ก่อนออกจากโปรแกรม ต้องการบันทึก Template ที่จัดทำค้างไว้หรือไม่?
ใช่ = บันทึก
ไม่ใช่ = ออกโดยไม่บันทึก
ยกเลิกหรือกากบาท = กลับไปทำงาน
~~~

พฤติกรรม

- Yes: บันทึก Payroll และ Procurement ที่เกี่ยวข้อง
- No: ออกโดยไม่บันทึก draft
- Cancel/กากบาท: ไม่ออก
- save fail: ยกเลิกการปิดและแจ้ง error

แนวคิดนี้ช่วยให้ผู้ใช้เข้าใจว่าเป็นการบันทึก Template/data ที่ทำค้าง ไม่ใช่การยืนยันว่า output Word ถูกบันทึกแล้ว

---

## 18. จุดที่แก้แล้ว จุดที่ปล่อย และจุดที่ไม่ต้องแก้

### 18.1 แก้แล้ว

| รายการ | สถานะ |
|---|---|
| 9. ใบสั่งจ้าง → 9. สัญญา | แก้แล้ว |
| route TOR P01–P18 | แก้แล้ว |
| page A/B/C/D | แก้แล้ว |
| C/D ทุก route 2/สอง | แก้แล้ว |
| ตำบลเขต/อำเภอเขต/จังหวัดเขต | แก้แล้ว |
| trim ตำบล/อำเภอ/จังหวัด | แก้แล้ว |
| ถนนลูกจ้าง | แก้แล้ว |
| UI เลขที่สัญญา | แก้แล้ว |
| dropdown วันทำสัญญา | แก้แล้ว |
| ปีสัญญา 2569/2570 | แก้แล้ว |
| ปีวันที่สั่งจ้าง Payroll 2569/2570 | แก้แล้ว |
| date validation | แก้แล้ว |
| salary 8,500/9,000/15,000/18,000 | แก้แล้ว |
| เงินรวม 12 เดือน | แก้แล้ว |
| เงินเดือนหารสามสิบมี “บาท” | แก้แล้ว |
| TEXT ลงท้าย บาทถ้วน | แก้แล้ว |
| Payroll token safety | แก้แล้ว |
| full render 49/49 | แก้แล้ว |
| standard installer/source ZIP | แก้แล้ว |
| legacy preservation | แก้แล้ว |
| close message | แก้แล้ว |

### 18.2 ปล่อยไว้โดยรู้ความเสี่ยง

#### Partial output

ถ้าไฟล์ที่ 7 ล้มเหลว ไฟล์ 1–6 อาจยังค้างใน output

สาเหตุได้แก่

- Word XML เสีย
- Word/OneDrive/antivirus lock
- output เขียนไม่ได้
- disk เต็ม
- filename/path มีปัญหา
- tag/XML เฉพาะไฟล์ผิด

template ปัจจุบันผ่าน 49/49 จึงเป็นความเสี่ยงต่ำใน workflow ปกติ แต่ยังเป็น design limitation

#### Manual JSON

saved_templates.json เขียนด้วย manual JSON builder และมี EscapeJson แล้ว แต่ยังไม่ใช่ serializer เต็มรูปแบบ หากค่าพิเศษหรือ schema เปลี่ยนอาจมีปัญหา

แนวทางอนาคต: ใช้ JSON serializer และ atomic write

#### Plaintext local data

ข้อมูลส่วนตัวและสัญญาใน Data/JSON/DOCX อ่านได้ในเครื่อง

เหมาะกับ offline single-user ที่ไว้ใจเครื่อง แต่ถ้าต้องการความปลอดภัยสูงควรใช้ ACL, DPAPI หรือ encryption ตามความเหมาะสม

### 18.3 ไม่ต้องแก้ logic รอบนี้

- fixed text ที่ต่างเล็กน้อยแต่ความหมาย/ผลลัพธ์เท่ากัน
- เลขรายการหรือผลลัพธ์ที่ผู้ใช้ตั้งใจจัดการ manual
- ไม่มีอากรในตัว 9. สัญญา แต่มีข้อความช่วยใน UI
- Payroll-only tags ที่ไม่ใช้ใน Procurement
- position/salary Khet70 ที่ Jangmaoมีชุดต่างกัน
- teachingFlag/twoSchoolsFlag ที่ Khet70 false ทั้งหมด ถ้า Jangmaoมี domain อื่น
- highlight ใน runtime เพราะเป็นเครื่องมือช่วยตรวจ template ไม่ใช่ renderer logic

---

## 19. วิธีนำไปใช้กับ Jangmao70

### ขั้นที่ 1: Freeze domain ก่อนเขียน code

สรุปให้เสร็จก่อน

- รายชื่อตำแหน่ง
- dropdown label
- ชื่อทางการในเอกสาร
- position → TOR
- position → quote
- จำนวนหน้า TOR/quote
- เงินเดือนผูกตำแหน่งหรือเลือกได้
- tag ของแต่ละเอกสาร
- required/optional
- ปีที่อนุญาต
- วันที่ dropdown หรือกรอกเอง

### ขั้นที่ 2: จัด template

- สำรองชุดเก่า
- วางไฟล์ใหม่ใน production Template
- ตรวจ Word เปิดได้
- ตรวจ tag
- ตรวจ page count
- ตรวจเอกสารลำดับ 9
- ไม่ให้ชื่อไฟล์เก่าค้างโดยไม่มี route

### ขั้นที่ 3: ทำ tag inventory

| Tag | Label | Model key | Section | Type | Required | Normalizer | Module |
|---|---|---|---|---|---|---|---|
| {ชื่อเขต} | ชื่อเขต | school.district | เขต | combo | ใช่ | district | Procurement |
| {ตำบลเขต} | ตำบลเขต | school.zoneSubdistrict | เขต | text | ใช่ | strip | Procurement |
| {เงินเดือน} | เงินเดือน | procurement.salary | เงิน | dropdown | ใช่ | resolver | Procurement |
| {วันทำสัญญา} | วันทำสัญญา | procurement.contractDay | สัญญา | dropdown | ใช่ | date | Procurement |

### ขั้นที่ 4: ทำ catalog/manifest

แยก

~~~text
position_catalog.json
salary_rates.json
template_manifest.json
template_tags.json
~~~

ออกจาก renderer

### ขั้นที่ 5: ทำ normalize

แยก function

~~~text
NormalizeDistrictName
StripPrefix
NormalizeThaiDate
NormalizeSalary
NormalizePerson
~~~

### ขั้นที่ 6: validate ก่อน render

ตรวจ required, numeric, ID, date, position, route, salary, page metadata และ selected documents

### ขั้นที่ 7: BuildValues แยก module

ใช้

~~~text
BuildProcurementValues(record)
BuildPayrollValues(record)
~~~

ทั้งคู่คืน Dictionary<string,string> แต่ไม่ควรปะปน semantic ระหว่างโมดูล

### ขั้นที่ 8: renderer

ต้องรองรับ

- Word run split
- header/footer
- token replacement
- literal value ที่เหมือน tag
- unresolved scan
- cleanup
- batch atomic commit ถ้าต้องการความสมบูรณ์สูง

### ขั้นที่ 9: full render

ถ้ามี 4 + 45 ต้องผ่าน 49/49; ถ้า Jangmaoมีจำนวนอื่นให้ discover จาก folder/manifest แล้ว test ตามจำนวนจริง

### ขั้นที่ 10: installer

สร้าง installer หลัง template, manifest, renderer และ full test ผ่านเท่านั้น

---

## 20. Pseudocode ที่ควรใช้

~~~text
function GenerateDocuments():
    raw = CaptureFormData()
    record = Clone(raw)

    Normalize(record)
    errors = Validate(record)
    if errors not empty:
        ShowErrors(errors)
        return

    route = Manifest.FindRoute(record.positionId)
    if route is null:
        ShowError("ไม่พบ route")
        return

    values = BuildValues(record, route)
    tempBatch = CreateTemporaryBatchFolder()

    try:
        for document in SelectedDocuments(record):
            source = ResolveContainedPath(document.relativePath)
            output = tempBatch / BuildSafeName(document, record)
            RenderDocx(source, output, values)
            AssertNoUnresolvedTags(output)

        CommitBatch(tempBatch, RealOutputFolder)
    catch error:
        DeleteTemporaryBatch(tempBatch)
        ShowError(error)
~~~

BuildValues

~~~text
function BuildValues(record, route):
    values = new Dictionary

    values["{ตำแหน่ง}"] = PositionCatalog[record.positionId].label
    values["{หน้าA}"] = route.torPageCount
    values["{หน้าB}"] = route.torPageCountText
    values["{หน้าC}"] = route.quotePageCount
    values["{หน้าD}"] = route.quotePageCountText

    values["{เงินเดือน}"] = Salary.Format(record.salary)
    values["{เงินเดือนTEXT}"] = ThaiMoney(record.salary)
    values["{เงินรวม}"] = Salary.Format(record.salary * 12)
    values["{เงินรวมTEXT}"] = ThaiMoney(record.salary * 12)
    values["{เงินเดือนหารสามสิบ}"] = Truncate(record.salary / 30) + " บาท"
    values["{เงินเดือนหารสามสิบTEXT}"] = ThaiMoney(Truncate(record.salary / 30))

    values["{ถนนลูกจ้าง}"] = record.employee.road
    values["{ตำบลลูกจ้าง}"] = StripPrefix(record.employee.subdistrict, "ตำบล")
    values["{อำเภอลูกจ้าง}"] = StripPrefix(record.employee.district, "อำเภอ")
    values["{จังหวัดลูกจ้าง}"] = StripPrefix(record.employee.province, "จังหวัด")

    return values
~~~

จุดสำคัญคือ formula และ route data อยู่ใน model/config ไม่กระจายอยู่ตามจุดแทนแท็ก

---

## 21. Checklist ก่อน release Jangmao70

### Template

- [ ] แบบสัญญา/เอกสาร 9 ถูกต้อง
- [ ] ไม่มีเอกสาร 9 เก่า
- [ ] TOR ครบ
- [ ] quote ครบ
- [ ] tag inventory ตรง Word
- [ ] ตรวจ header/footer
- [ ] ตรวจ fixed text ตามกฎหมาย
- [ ] ตรวจ pagination หลังแก้

### Mapping

- [ ] positionId ไม่ซ้ำ
- [ ] route ไม่ซ้ำ
- [ ] TOR/quote จับคู่ถูก
- [ ] A/B ตรง
- [ ] C/D ตรง
- [ ] hash update
- [ ] verifier ผ่าน

### Form

- [ ] UI label เข้าใจง่าย
- [ ] model key ไม่ชน
- [ ] required/optional ถูก
- [ ] วันใช้ control ตาม requirement
- [ ] จำกัดปีถูก
- [ ] invalid date ถูกปฏิเสธ
- [ ] zone address trim ถูก
- [ ] road mapping ครบ

### Money

- [ ] salary options/config ครบ
- [ ] TEXT ลงท้าย บาทถ้วน
- [ ] total ใช้จำนวนเดือนถูก
- [ ] หารสามสิบชัด
- [ ] numeric มี บาท
- [ ] tax แสดงตรงจุด

### Renderer

- [ ] run split
- [ ] header/footer
- [ ] token test
- [ ] unresolved tag test
- [ ] output cleanup
- [ ] พิจารณา atomic batch

### Installer

- [ ] build จาก dist หลัง QA
- [ ] destination ถูก
- [ ] AppId/identity เป็นของ Jangmao
- [ ] backup Template ก่อน upgrade
- [ ] cleanup ไฟล์เก่าแบบระบุ path
- [ ] ไม่ใช้ wildcard ลบกว้าง
- [ ] shortcut ถูก
- [ ] uninstaller scope ถูก
- [ ] legacy แยกชื่อ
- [ ] SHA-256 ถูก
- [ ] clean install ผ่าน
- [ ] upgrade install ผ่าน
- [ ] output หลังติดตั้งผ่าน

---

## 22. Artifact ล่าสุดของ Khet70

standard

~~~text
H:\CodexProjects\Khet70\release\Khet70-Installer\Khet70-Setup.exe
H:\CodexProjects\Khet70\release\Khet70-Installer-standard.zip
H:\CodexProjects\Khet70\release\Khet70-Source-standard.zip
~~~

SHA-256

| Artifact | SHA-256 |
|---|---|
| Khet70-Setup.exe | 4ED85651884510570F8F50E379C0DA20A37D800DEBCC36C3D61F7A5C9998FE34 |
| Khet70-Installer-standard.zip | C14093034DD906ED6F6E09127C4DA1D4FE9F74965FEAAD6A54AF2429AF8A109B |
| Khet70-Source-standard.zip | 14B69525ABEF38C5D2DC1A53D86030F0A2590993901F0D3FFB23C70752CE090D |

legacy

~~~text
release\legacy\Khet70-Setup-legacy.exe
release\legacy\Khet70-Installer-legacy.zip
~~~

SHA-256 legacy

| Artifact | SHA-256 |
|---|---|
| Khet70-Setup-legacy.exe | 6B57FDFFA67FCFF0B4F0D306FB70EB11F90CAF5126660D39EDEA78C71A5776D7 |
| Khet70-Installer-legacy.zip | 50246AB166A69A92F9B58FC9821D7317B25EF8E30D084A3BCCDB02E0690832D6 |

รายงานนี้ถูกสร้างหลัง source ZIP ล่าสุด หากต้องการให้รายงานติดใน source ZIP ให้ build source archive ใหม่

---

## 23. Prompt สำหรับส่งต่อให้ Jangmao70

~~~text
ให้นำแนวคิดจาก Khet70 ไปใช้กับ Jangmao70 โดยห้ามคัดลอกค่าตำแหน่ง เงินเดือน หรือกฎวันที่ของ Khet70 แบบตรง ๆ เพราะ domain ของ Jangmao70 อาจต่างกัน

เป้าหมายคือ เมื่อผมเปลี่ยน Template, TOR, แบบสัญญา หรือเอกสารแนบท้ายแล้ว โปรแกรมต้องสร้าง output ได้เหมือน Khet70

1. ใช้ template manifest เป็น source of truth
   - central documents
   - route ต่อ positionId
   - path ของ TOR/quote
   - SHA-256
   - page count numeric/text
   - ห้าม hard-code ชื่อไฟล์และจำนวนหน้าใน renderer

2. แยกชั้น
   - UI label
   - model key
   - template tag
   - BuildValues
   - DOCX renderer

3. ทำ tag inventory จาก Word จริงก่อน coding
   - tag
   - label
   - model key
   - module
   - section
   - field type
   - required/optional
   - normalizer
   - validator
   - ตัวอย่างค่า

4. Data flow:
   CaptureFormData
   → Normalize
   → Validate
   → Resolve position/route
   → BuildValues
   → Render DOCX
   → Scan unresolved tags
   → Output

5. แยก normalization
   - Trim
   - strip ตำบล/อำเภอ/จังหวัดตาม domain
   - normalize หน่วยงาน
   - money format
   - Thai money text
   - Thai date validation

6. รวมสูตรเงินในจุดเดียว
   - เงินเดือน
   - เงินเดือนTEXT ลงท้าย บาทถ้วน
   - เงินรวมตามจำนวนเดือนของ Jangmao
   - เงินรวมTEXT
   - เงินเดือนหารสามสิบถ้าใช้
   - ภาษี/อากรถ้าใช้
   ห้าม copy salary options ของ Khet70 โดยไม่ตรวจ config Jangmao

7. แยกความหมายวันที่
   - วันทำสัญญา
   - วันที่สั่งจ้าง
   - วันที่ส่งเบิก
   - เดือนส่งมอบ
   - ปีงบประมาณ

8. DOCX renderer ต้อง:
   - แก้ document/header/footer XML
   - รองรับ tag ข้าม run
   - ใช้ PUA token
   - รองรับค่าจริงที่มีรูปแบบ {tag}
   - ตรวจ unresolved tag
   - cleanup output file
   - พิจารณา temp batch + atomic commit

9. Template replacement:
   - backup เดิม
   - วางไฟล์ใหม่
   - ตรวจ count
   - ตรวจ tag
   - ตรวจ fixed text
   - ตรวจ pagination
   - update manifest/hash/page count
   - run verifier
   - build
   - render test
   - ค่อยสร้าง installer

10. Installer รุ่นใหม่:
    - build จาก dist ที่ผ่าน QA
    - ใช้ Inno Setup หรือ installer มาตรฐาน
    - ติดตั้งใน install root เฉพาะของ Jangmao
    - backup Template ก่อน upgrade
    - cleanup ไฟล์เก่าแบบ explicit path
    - ไม่ใช้ wildcard ลบกว้าง
    - สร้าง shortcut และ uninstaller
    - ทดสอบ clean install, upgrade install และ uninstall scope
    - เก็บ legacy แยกจาก standard
    - ทำ SHA-256 ของ artifact

11. Regression test:
    - date valid/invalid
    - money formula
    - literal value ที่เหมือน {tag}
    - render ทุก template
    - no unresolved tags
    - route ครบ
    - installer smoke test

ให้รายงานผลเป็น Markdown แบ่ง:
- สิ่งที่แก้แล้ว
- สิ่งที่ยังไม่แก้
- สิ่งที่ไม่ต้องแก้
- tag contract
- data flow
- route/page mapping
- installer flow
- test evidence
- release risk
~~~

---

## 24. บทสรุปสำหรับผู้ดูแล Jangmao70

สิ่งที่ควรยกไป

~~~text
Word template = data/config
manifest = mapping contract
position catalog = domain catalog
salary config = domain rules
BuildValues = single source of rendered values
renderer = infrastructure
validation = gate ก่อนสร้าง
full render test = หลักฐานว่า template ใช้งานได้
installer = packaging หลัง QA
~~~

สิ่งที่ไม่ควรยกไปแบบตรง ๆ

~~~text
รายชื่อตำแหน่ง Khet70
เงินเดือน Khet70
ค่า A/B Khet70
ค่า C/D Khet70
ปีที่ Khet70 เปิด
fixed text เฉพาะเขต
กฎ teaching/two schools ของ Khet70
~~~

เมื่อ Jangmao70 แทน TOR หรือแบบสัญญาแล้ว ผลลัพธ์ที่ต้องได้

1. โปรแกรมเห็น Template ใหม่จาก path ถูกต้อง
2. route เลือกไฟล์ตาม positionId ถูก
3. ฟอร์มถูก normalize และ validate
4. ทุก tag ถูก map
5. จำนวนหน้าและเงินคำนวณตาม domain ใหม่
6. เอกสารทุกใบสร้างจริง
7. ไม่มี tag ค้าง
8. test รายงานผลครบ
9. installer ใช้ source เดียวกับที่ทดสอบ
10. ความเสี่ยงที่ยังยอมรับไว้ถูกบันทึกชัดเจน

จบรายงาน Handoff Khet70 → Jangmao70
