# Khet70

Khet70 is a separate build of the Jangmao70 application workflow. The source was copied from `H:\CodexProjects\346` and adapted surgically for the Khet70 identity and storage paths.

The Khet70 package contains the real Procurement (45 DOCX) and Payroll (4 DOCX) templates, the position catalog, and the three shared salary rates from the Khet70 source files.

## Build

From PowerShell in this folder:

```powershell
.\build-exe-Khet70.ps1
.\build-installer-Khet70.ps1
```

Outputs:

- `dist\Khet70\Khet70.exe`
- `release\Khet70-Installer\Khet70-Setup.exe`
- `release\Khet70-Installer.zip`

The installer ZIP contains the standalone Inno Setup installer:

```text
Khet70-Setup.exe
```

Run only `Khet70-Setup.exe`. The application files are packed inside the Setup and are unpacked to a temporary folder only while installing; users do not need to open or manage a Payload folder. Setup then copies the complete application into `%LOCALAPPDATA%\Khet70`, creates the Data/Output folders and shortcuts, and asks whether to open Khet70 immediately.

`verify-manifest.ps1` checks the Khet70 identity, manifest containment, and hashes for all 49 packaged DOCX files.

Version 1.1.0 adds user-initiated updates and program information above all tabs. After editing DOCX originals, run `refresh-template-hashes.ps1`, then build the installer. Release files are copied to `assets/Khet70` for the verified `RobbyGrean/Jangmao70` repository; Khet70 uses its own folder and file names. See `UPDATE-Khet70.md` for update behavior, tests, and publication checks. Building prepares local files and does not publish them.

## Installed paths

- `%LOCALAPPDATA%\Khet70\Khet70.exe`
- `%LOCALAPPDATA%\Khet70\Data`
- `%LOCALAPPDATA%\Khet70\Config`
- `%LOCALAPPDATA%\Khet70\Template`
- `%LOCALAPPDATA%\Khet70\Output`
- Desktop shortcut: `Khet70.lnk`
- Start Menu folder: `Khet70`

The installer and uninstaller operate only on the Khet70 install root and shortcuts targeting Khet70.
## Portable copy behavior

When rebuilt from the updated source, a complete copy of the `dist\Khet70` application folder can run from a writable local folder such as `D:\Khet70portable`. `Data`, `Template`, and `Output` are all stored beside `Khet70.exe`, so saved templates, user records, editable document templates, and generated documents travel with the portable folder. The standard installer uses `%LOCALAPPDATA%\Khet70`, which gives the same layout for an installed copy.

On the first launch from a portable folder, the app copies existing `Data`, `Template`, and `Output` content from `%LOCALAPPDATA%\Khet70` if present. It preserves the old AppData tree and backs up an existing portable `Template` folder before importing old user templates. A fresh portable copy creates the folders it needs at startup.

Portable folders must be writable. Existing executables keep their old path behavior until replaced with a build from the updated source. Files in a portable folder are not tested as release artifacts by this documentation change.
