﻿param([string]$DownloadRoot = (Join-Path $PSScriptRoot 'assets\Khet70'), [switch]$AllowUnpublished)
$ErrorActionPreference = 'Stop'
$info = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Khet70-release.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$manifest = Get-Content -LiteralPath (Join-Path $DownloadRoot 'update.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$setup = Join-Path $DownloadRoot 'Khet70-Setup.exe'
$expectedUrl = "https://raw.githubusercontent.com/$($info.repository)/$($info.branch)/$($info.downloadPath)/Khet70-Setup.exe"
if (-not $info.repository -and -not $AllowUnpublished) { throw 'Khet70 repository has not been verified/configured' }
if ($info.repository -and $manifest.installerUrl -cne $expectedUrl) { throw 'Wrong Khet70 installer URL' }
if ($manifest.product -cne 'Khet70' -or $manifest.schemaVersion -ne 1 -or $manifest.version -cne $info.version) { throw 'Wrong manifest identity/version' }
if ((Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash -ne $manifest.installerSha256) { throw 'Setup checksum mismatch' }
if ([version]([Diagnostics.FileVersionInfo]::GetVersionInfo($setup).FileVersion) -ne [version]"$($info.version).0") { throw 'Installer version mismatch' }
$dist = Join-Path $PSScriptRoot 'dist\Khet70'
if ((Get-FileHash -LiteralPath (Join-Path $dist 'release-files.json') -Algorithm SHA256).Hash -ne $manifest.payloadSha256) { throw 'Payload inventory checksum mismatch' }
$inventory = Get-Content -LiteralPath (Join-Path $dist 'release-files.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($inventory.version -ne $info.version) { throw 'Payload version mismatch' }
foreach ($entry in $inventory.files.PSObject.Properties) {
    if ((Get-FileHash -LiteralPath (Join-Path $dist $entry.Name) -Algorithm SHA256).Hash -ne $entry.Value) { throw "Payload mismatch: $($entry.Name)" }
}
foreach ($line in Get-Content -LiteralPath (Join-Path $DownloadRoot 'Khet70-Checksums.txt')) {
    if ($line -notmatch '^([A-Fa-f0-9]{64})  ([A-Za-z0-9_.-]+)$') { throw 'Malformed checksum record' }
    if ((Get-FileHash -LiteralPath (Join-Path $DownloadRoot $Matches[2]) -Algorithm SHA256).Hash -ne $Matches[1]) { throw 'Artifact checksum mismatch' }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach ($name in @('Khet70-Installer.zip','Khet70-Installer-standard.zip')) {
    $zip = [IO.Compression.ZipFile]::OpenRead((Join-Path $DownloadRoot $name))
    try {
        if ($zip.Entries.Count -ne 1 -or $zip.Entries[0].FullName -ne 'Khet70-Setup.exe') { throw 'Installer ZIP must contain only Setup.exe' }
        $stream = $zip.Entries[0].Open()
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $hash = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','') } finally { $sha.Dispose(); $stream.Dispose() }
        if ($hash -ne $manifest.installerSha256) { throw 'Installer ZIP differs from direct Setup.exe' }
    } finally { $zip.Dispose() }
}
Write-Host "PASS release bundle $($info.version), Setup SHA256=$($manifest.installerSha256)"
