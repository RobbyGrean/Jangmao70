﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path $PSScriptRoot).Path
foreach ($module in @('Payroll','Procurement')) {
    $path = Join-Path $root "Config\$module\template_manifest.json"
    $manifest = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    $templateRoot = Join-Path $root "Template\$module"
    $count = 0
    $documents = if ($module -eq 'Payroll') { $manifest.documents } else { $manifest.centralDocuments }
    foreach ($document in $documents) {
        $document.sha256 = (Get-FileHash -LiteralPath (Join-Path $templateRoot $document.relativePath) -Algorithm SHA256).Hash.ToLowerInvariant()
        $count++
    }
    if ($module -eq 'Procurement') {
        foreach ($route in $manifest.routes) {
            $route.torSha256 = (Get-FileHash -LiteralPath (Join-Path $templateRoot $route.tor) -Algorithm SHA256).Hash.ToLowerInvariant()
            $route.quoteSha256 = (Get-FileHash -LiteralPath (Join-Path $templateRoot $route.quote) -Algorithm SHA256).Hash.ToLowerInvariant()
            $count += 2
        }
    }
    [IO.File]::WriteAllText($path, ($manifest | ConvertTo-Json -Depth 12), (New-Object Text.UTF8Encoding($false)))
    Write-Host "Refreshed $module hashes: $count documents"
}
& (Join-Path $root 'verify-manifest.ps1')
