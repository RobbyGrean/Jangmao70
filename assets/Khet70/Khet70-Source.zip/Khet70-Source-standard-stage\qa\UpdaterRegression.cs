using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Khet70;

internal static class UpdaterRegression
{
    private static int passed;
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    private static void Assert(bool value, string name)
    {
        if (!value) throw new Exception("FAIL " + name);
        passed++;
        Console.WriteLine("PASS " + name);
    }
    private static void Reject(Action action, string name)
    {
        try { action(); }
        catch (InvalidDataException) { Assert(true, name); return; }
        throw new Exception("Expected rejection: " + name);
    }
    private static object Get(object obj, string name) { return obj.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(obj); }
    private static void Set(object obj, string name, object value) { obj.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance).SetValue(obj, value); }
    private static string Clone(UpdateManifest manifest) { return Json.Serialize(manifest); }

    [STAThread]
    private static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        var root = AppDomain.CurrentDomain.BaseDirectory;
        // The harness lives in qa/update-run with a copy of dist; no real AppData initialization.
        Directory.CreateDirectory(Path.Combine(root, "Data"));
        File.WriteAllText(Path.Combine(root, "Data", ".portable-state-migrated-v1"), "QA");
        var manifest = Json.Deserialize<UpdateManifest>(File.ReadAllText(args[0]));
        manifest = Khet70Update.ParseManifest(Clone(manifest));
        Assert(!Khet70Update.NeedsUpdate(manifest), "current version with intact shipped files needs no update");
        Assert(Khet70Update.MatchesPayload(root, manifest, true), "all packaged files match inventory");
        var actualVersion = manifest.version;
        manifest.version = "99.0.0";
        Assert(Khet70Update.NeedsUpdate(manifest), "new version offered");
        manifest.version = "0.0.1";
        Assert(!Khet70Update.NeedsUpdate(manifest), "older release not offered");
        Reject(delegate { Khet70Update.DownloadAsync(manifest, null).GetAwaiter().GetResult(); }, "download API rejects downgrade");
        manifest.version = actualVersion + ".0";
        manifest = Khet70Update.ParseManifest(Clone(manifest));
        Assert(manifest.version == actualVersion, "version normalization");
        var payloadFile = Path.Combine(root, "app_database.json");
        var savedDatabase = File.ReadAllBytes(payloadFile);
        File.WriteAllText(payloadFile, "old-data");
        Assert(Khet70Update.NeedsUpdate(manifest), "same version repairs stale defaults");
        File.WriteAllBytes(payloadFile, savedDatabase);
        var template = Directory.GetFiles(Path.Combine(root, "Template"), "*.docx", SearchOption.AllDirectories)[0];
        var templateBytes = File.ReadAllBytes(template);
        File.WriteAllText(template, "user edited template");
        Assert(!Khet70Update.NeedsUpdate(manifest), "user-edited template does not force same-version repair");
        Assert(!Khet70Update.MatchesPayload(root, manifest, true), "post-install check detects stale template");
        File.WriteAllBytes(template, templateBytes);
        var valid = Clone(manifest);
        manifest.installerUrl = "https://github.com/RobbyGrean/Jangmao70/blob/main/assets/Khet70/Khet70-Setup.exe";
        Reject(delegate { Khet70Update.ParseManifest(Clone(manifest)); }, "blob URL rejected");
        manifest.installerUrl = "https://raw.githubusercontent.com/RobbyGrean/Jangmao70/main/assets/downloads/Jangmao70-Setup.exe";
        Reject(delegate { Khet70Update.ParseManifest(Clone(manifest)); }, "other product installer rejected");
        manifest = Json.Deserialize<UpdateManifest>(valid);
        manifest.product = "Jangmao70";
        Reject(delegate { Khet70Update.ParseManifest(Clone(manifest)); }, "other product manifest rejected");
        manifest = Json.Deserialize<UpdateManifest>(valid);
        manifest.installerSha256 = "bad";
        Reject(delegate { Khet70Update.ParseManifest(Clone(manifest)); }, "malformed SHA256 rejected");
        manifest = Json.Deserialize<UpdateManifest>(valid);
        var installer = Path.Combine(root, "test-installer.bin");
        File.WriteAllText(installer, "test payload");
        manifest.installerSha256 = Khet70Update.HashFile(installer);
        Khet70Update.VerifyInstaller(installer, manifest.installerSha256);
        Assert(true, "valid checksum accepted");
        File.WriteAllText(installer, "changed after download");
        Reject(delegate { Khet70Update.ScheduleInstaller(installer, manifest); }, "checksum rechecked before scheduling helper");
        Assert(!File.Exists(Path.Combine(root, "Data", "pending-update.json")), "failed checksum leaves no receipt");

        var pending = new PendingUpdate { manifest = manifest, appDirectory = root };
        var pendingPath = Path.Combine(root, "Data", "pending-update.json");
        File.WriteAllText(pendingPath, Json.Serialize(pending));
        File.WriteAllText(payloadFile, "stale");
        Assert(Khet70Update.ReadUpdateResult(root) != null && File.Exists(pendingPath), "partial update cannot report success");
        File.WriteAllBytes(payloadFile, savedDatabase);
        pending.appDirectory = Path.Combine(root, "other-install");
        File.WriteAllText(pendingPath, Json.Serialize(pending));
        Assert(Khet70Update.ReadUpdateResult(root) == null && File.Exists(pendingPath), "another install cannot consume receipt");
        pending.appDirectory = root;
        pending.manifest.version = "99.0.0";
        File.WriteAllText(pendingPath, Json.Serialize(pending));
        Assert(Khet70Update.ReadUpdateResult(root) != null && File.Exists(pendingPath), "old executable cannot report success");
        pending.manifest.version = actualVersion;
        File.WriteAllText(pendingPath, Json.Serialize(pending));
        Assert(Khet70Update.ReadUpdateResult(root).Contains("สำเร็จ") && !File.Exists(pendingPath), "matching installation confirms success once");
        Assert(Khet70Update.ReadUpdateResult(root) == null, "success not repeated");

        Assert(WebRequest.RegisterPrefix("https://raw.githubusercontent.com/", new MockFactory()), "mock transport installed");
        MockRequest.Manifest = valid;
        MockRequest.Payload = Encoding.UTF8.GetBytes("test payload");
        var remote = Khet70Update.CheckAsync().GetAwaiter().GetResult();
        remote.installerSha256 = manifest.installerSha256;
        Assert(remote.version == actualVersion, "real async manifest path");
        var downloaded = Khet70Update.DownloadAsync(remote, null).GetAwaiter().GetResult();
        Assert(Khet70Update.HashFile(downloaded) == remote.installerSha256, "async download checksum verified");
        File.Delete(downloaded);
        MockRequest.Payload = Encoding.UTF8.GetBytes("wrong");
        Reject(delegate { Khet70Update.DownloadAsync(remote, null).GetAwaiter().GetResult(); }, "async corrupt download rejected");
        MockRequest.Fail = true;
        try { Khet70Update.CheckAsync().GetAwaiter().GetResult(); throw new Exception("Expected network failure"); }
        catch (WebException) { Assert(true, "network failure propagated without installation"); }
        MockRequest.Fail = false;
        MockRequest.Delay = 100;
        var slow = Khet70Update.CheckAsync();
        Assert(!slow.IsCompleted, "network check does not block UI thread");
        slow.GetAwaiter().GetResult();
        MockRequest.Delay = 0;
        MockRequest.Delay = 31000;
        var timeoutWatch = Stopwatch.StartNew();
        try { Khet70Update.CheckAsync().GetAwaiter().GetResult(); throw new Exception("Expected timeout"); }
        catch (TimeoutException) { Assert(timeoutWatch.Elapsed.TotalSeconds < 35, "manifest request enforces 30-second total timeout"); }
        MockRequest.Delay = 0;
        Assert(!File.Exists(pendingPath), "network failures and timeout leave no installation receipt");

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using (var form = new Khet70ShellForm())
        {
            form.Show();
            Application.DoEvents();
            CheckTemplateContracts(form, root);
            var tabs = (TabControl)Get(form, "tabs");
            var button = (Button)Get(form, "updateButton");
            foreach (var size in new[] { new Size(1236,889), form.MinimumSize })
            {
                form.Size = size;
                Application.DoEvents();
                var bar = form.Controls["updateBar"];
                Assert(bar.Bounds.Bottom <= tabs.Bounds.Top, "toolbar above tabs at " + size.Width);
                foreach (TabPage page in tabs.TabPages)
                {
                    tabs.SelectedTab = page;
                    Application.DoEvents();
                    var rectangle = form.RectangleToClient(button.RectangleToScreen(button.ClientRectangle));
                    Assert(button.Visible && form.ClientRectangle.Contains(rectangle), "update button visible on " + page.Text + " at " + size.Width);
                }
                using (var bitmap = new Bitmap(form.Width, form.Height))
                {
                    form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
                    bitmap.Save(Path.Combine(root, "layout-" + size.Width + ".png"));
                }
            }
            // Drive the actual close handler, answering the standard save dialog through its native button.
            Set(form, "pendingInstaller", installer);
            Set(form, "pendingManifest", manifest);
            AnswerDialog(2); // IDCANCEL
            form.Close();
            Application.DoEvents();
            Assert(!form.IsDisposed && !File.Exists(pendingPath), "canceling close does not launch installer");
            // Force the payroll save to fail by using a file as its Data directory.
            var payrollData = Path.Combine(root, "Data", "Payroll");
            if (Directory.Exists(payrollData)) Directory.Move(payrollData, payrollData + "-backup");
            File.WriteAllText(payrollData, "block directory creation");
            var payroll = (Form)Get(form, "payrollForm");
            // Supply a dirty payroll state through an actual editable field.
            var fields = (Dictionary<string, Control>)Get(payroll, "fieldBoxes");
            foreach (var box in fields.Values) { if (box is TextBox && box.Visible && !((TextBox)box).ReadOnly) { box.Text = "QA unsaved"; } }
            Assert((bool)payroll.GetType().GetProperty("IsDirty").GetValue(payroll, null), "payroll dirty before failed-save test");
            // Missing active template opens the existing save-new dialog, canceling it must also block close.
            AnswerDialog(6); // IDYES on exit prompt
            AnswerFormCancel("บันทึก");
            form.Close();
            Application.DoEvents();
            Assert(!form.IsDisposed && !File.Exists(pendingPath), "canceling save prevents installation");
            File.Delete(payrollData);
            // An existing active template takes the direct-save branch: force an IO failure there.
            var recordType = typeof(Khet70ShellForm).Assembly.GetType("Khet70.Program+SavedTemplateRecord", true);
            Set(payroll, "activeTemplate", Activator.CreateInstance(recordType, true));
            File.WriteAllText(payrollData, "block directory creation");
            AnswerDialog(6);
            AnswerNativeDialog("บันทึกข้อมูล", 2); // Native MB_OK uses the cancel/close command in this runtime.
            form.Close();
            Application.DoEvents();
            Assert(!form.IsDisposed && !File.Exists(pendingPath), "failed disk save prevents installation");
            File.Delete(payrollData);
            Set(form, "pendingInstaller", null);
            Set(form, "closingConfirmed", true);
            form.Close();
        }
        Console.WriteLine("Updater checks passed: " + passed);
    }

    private static void CheckTemplateContracts(Khet70ShellForm form, string root)
    {
        var module = Get(form, "procurementModule");
        var build = module.GetType().GetMethod("BuildValues", BindingFlags.NonPublic | BindingFlags.Instance);
        var manifest = Json.Deserialize<ProcurementManifest>(File.ReadAllText(Path.Combine(root, "Config", "Procurement", "template_manifest.json")));
        Dictionary<string, string> procurementValues = null;
        foreach (var route in manifest.routes)
        {
            var record = WorkingRecord.CreateEmpty();
            record.Procurement.PositionId = route.positionId;
            record.Procurement.Salary = "18000";
            procurementValues = (Dictionary<string, string>)build.Invoke(module, new object[] { record });
            Assert(procurementValues["{หน้าA}"] == "4" && procurementValues["{หน้าB}"] == "สี่" && procurementValues["{หน้าC}"] == "2" && procurementValues["{หน้าD}"] == "สอง", "4/2 page mapping " + route.positionId);
        }
        var procurementFiles = Directory.GetFiles(Path.Combine(root, "Template", "Procurement"), "*.docx", SearchOption.AllDirectories);
        foreach (var file in procurementFiles)
        {
            var missing = Khet70DocxRenderer.FindBusinessTags(file).Where(tag => !procurementValues.ContainsKey(tag)).ToArray();
            if (missing.Length > 0) throw new Exception("Unmapped procurement tags: " + file + " " + string.Join(", ", missing));
        }
        Assert(procurementFiles.Length == 45, "all 45 procurement templates use tags supported by real BuildValues");
        var payroll = (Form)Get(form, "payrollForm");
        var fields = (Dictionary<string, Control>)Get(payroll, "fieldBoxes");
        var values = fields.ToDictionary(item => item.Key, item => "QA");
        values["{ชื่อโรงเรียน}"] = "";
        payroll.GetType().GetMethod("NormalizeValues", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(payroll, new object[] { values });
        var payrollFiles = Directory.GetFiles(Path.Combine(root, "Template", "Payroll"), "*.docx", SearchOption.AllDirectories);
        foreach (var file in payrollFiles)
        {
            var missing = Khet70DocxRenderer.FindBusinessTags(file).Where(tag => !values.ContainsKey(tag)).ToArray();
            if (missing.Length > 0) throw new Exception("Unmapped payroll tags: " + file + " " + string.Join(", ", missing));
        }
        Assert(payrollFiles.Length == 4, "all 4 payroll templates use supported fields and aliases");
    }

    [System.Runtime.InteropServices.DllImport("user32.dll", CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
    private static extern IntPtr FindWindow(string cls, string title);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr GetDlgItem(IntPtr window, int id);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr window, uint message, IntPtr w, IntPtr l);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    private static void AnswerDialog(int id)
    {
        AnswerNativeDialog("ปิด Khet70", id);
    }
    private static void AnswerNativeDialog(string title, int id)
    {
        var timer = new System.Windows.Forms.Timer { Interval = 100 };
        timer.Tick += delegate {
            var window = FindWindow("#32770", title);
            if (window == IntPtr.Zero) return;
            uint owner;
            GetWindowThreadProcessId(window, out owner);
            if (owner != Process.GetCurrentProcess().Id) return;
            timer.Stop();
            timer.Dispose();
            SendMessage(window, 0x111, new IntPtr(id), IntPtr.Zero);
        };
        timer.Start();
    }
    private static void AnswerFormCancel(string title)
    {
        // The WinForms save-mode dialog is closed on the UI thread, just as the user presses its X.
        var timer = new System.Windows.Forms.Timer { Interval = 100 };
        timer.Tick += delegate {
            foreach (Form form in Application.OpenForms)
                if (!(form is Khet70ShellForm) && form.TopLevel && form.Modal) { timer.Stop(); form.Close(); timer.Dispose(); break; }
        };
        timer.Start();
    }

    private sealed class MockFactory : IWebRequestCreate { public WebRequest Create(Uri uri) { return new MockRequest(uri); } }
    private sealed class MockRequest : WebRequest
    {
        public static string Manifest;
        public static byte[] Payload;
        public static bool Fail;
        public static int Delay;
        private readonly Uri uri;
        private TaskCompletionSource<WebResponse> pending;
        private AsyncCallback pendingCallback;
        public MockRequest(Uri uri) { this.uri = uri; }
        public override WebHeaderCollection Headers { get; set; }
        public override string Method { get; set; }
        public override int Timeout { get; set; }
        public override Uri RequestUri { get { return uri; } }
        public override IAsyncResult BeginGetResponse(AsyncCallback callback, object state)
        {
            var completion = new TaskCompletionSource<WebResponse>(state);
            pending = completion;
            pendingCallback = callback;
            ThreadPool.QueueUserWorkItem(delegate {
                Thread.Sleep(Delay);
                bool completed;
                if (Fail) completed = completion.TrySetException(new WebException("QA offline", WebExceptionStatus.ConnectFailure));
                else completed = completion.TrySetResult(new MockResponse(uri, uri.AbsolutePath.EndsWith("update.json") ? Encoding.UTF8.GetBytes(Manifest) : Payload));
                if (completed && callback != null) callback(completion.Task);
            });
            return completion.Task;
        }
        public override WebResponse EndGetResponse(IAsyncResult result) { return ((Task<WebResponse>)result).GetAwaiter().GetResult(); }
        public override void Abort()
        {
            if (pending != null && pending.TrySetException(new WebException("QA canceled", WebExceptionStatus.RequestCanceled)) && pendingCallback != null)
                pendingCallback(pending.Task);
        }
    }
    private sealed class MockResponse : WebResponse
    {
        private readonly Uri uri;
        private readonly byte[] bytes;
        public MockResponse(Uri uri, byte[] bytes) { this.uri=uri; this.bytes=bytes; }
        public override long ContentLength { get { return bytes.Length; } set { } }
        public override Uri ResponseUri { get { return uri; } }
        public override WebHeaderCollection Headers { get { return new WebHeaderCollection(); } }
        public override Stream GetResponseStream() { return new MemoryStream(bytes); }
    }
}
