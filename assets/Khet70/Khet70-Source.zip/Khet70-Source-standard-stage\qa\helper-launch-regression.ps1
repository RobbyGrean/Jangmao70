﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$work = Join-Path $PSScriptRoot ('helper-update-' + [Guid]::NewGuid().ToString('N'))
$appRoot = Join-Path $work 'portable copy ทดสอบ'
New-Item -ItemType Directory -Path $appRoot -Force | Out-Null
Copy-Item -Path (Join-Path $root 'dist\Khet70\*') -Destination $appRoot -Recurse
$helper = Join-Path $work 'Khet70-UpdateHelper.exe'
Copy-Item -LiteralPath (Join-Path $root 'dist\Khet70\Khet70.exe') -Destination $helper
$probe = Join-Path $work 'Khet70-Setup.exe'
& 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe' /nologo /codepage:65001 /target:exe /reference:System.Web.Extensions.dll "/out:$probe" (Join-Path $PSScriptRoot 'UpdateInstallerProbe.cs')
if ($LASTEXITCODE -ne 0) { throw 'Probe compilation failed' }
$manifest = Get-Content -LiteralPath (Join-Path $root 'assets\Khet70\update.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$manifest.installerSha256 = (Get-FileHash -LiteralPath $probe -Algorithm SHA256).Hash
$original = Start-Process powershell.exe -ArgumentList @('-NoProfile','-Command','Start-Sleep -Seconds 3') -PassThru -WindowStyle Hidden
$request = [ordered]@{ manifest=$manifest; appDirectory=$appRoot; installerPath=$probe; processId=$original.Id; processStartTicks=$original.StartTime.ToUniversalTime().Ticks }
$requestPath = Join-Path $work 'request.json'
[IO.File]::WriteAllText($requestPath, ($request | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
$process = Start-Process -FilePath $helper -ArgumentList ('--apply-update "' + $requestPath + '"') -PassThru -WindowStyle Hidden
Start-Sleep -Milliseconds 300
$resultPath = Join-Path $work 'installer-probe.json'
if (Test-Path -LiteralPath $resultPath) { throw 'Installer launched before original process exited' }
Write-Output 'PASS helper waits for original process exit'
if (-not $original.WaitForExit(10000) -or -not $process.WaitForExit(10000)) { throw 'Helper launch timed out' }
for ($attempt = 0; $attempt -lt 50 -and -not (Test-Path -LiteralPath $resultPath); $attempt++) { Start-Sleep -Milliseconds 100 }
$result = Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($result.originalStillRunning) { throw 'Original process was still running at launch' }
Write-Output 'PASS original process fully exited before installer launch'
if ($result.arguments[0] -cne "/DIR=$appRoot" -or $result.arguments[1] -ne '/NORESTART' -or $result.arguments[2] -ne '/NOAUTORUN') { throw 'Wrong installer target/arguments' }
Write-Output 'PASS exact portable path with spaces and Thai text passed to installer'
$receiptPath = Join-Path $appRoot 'Data\pending-update.json'
$receipt = Get-Content -LiteralPath $receiptPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($receipt.appDirectory -cne $appRoot -or $receipt.manifest.installerSha256 -ne $manifest.installerSha256) { throw 'Wrong update receipt' }
Write-Output 'PASS helper writes receipt scoped to target installation'
Write-Output "Helper evidence: $work"
