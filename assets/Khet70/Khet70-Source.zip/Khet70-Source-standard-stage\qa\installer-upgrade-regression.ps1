﻿param([string]$LegacyExe)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$work = Join-Path $PSScriptRoot ('installer-update-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$setup = Join-Path $root 'assets\Khet70\Khet70-Setup.exe'
$dist = Join-Path $root 'dist\Khet70'
$inventory = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $dist 'release-files.json') | ConvertFrom-Json
function Assert($condition, $name) { if (-not $condition) { throw "FAIL $name" }; Write-Output "PASS $name" }
function Install($target, $expectedExit = 0) {
    $log = Join-Path $work ((Split-Path $target -Leaf) + '-' + [Guid]::NewGuid().ToString('N') + '.log')
    $arguments = @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/NOAUTORUN','/ISOLATEDTEST',('/DIR="' + $target + '"'),('/LOG="' + $log + '"'))
    $process = Start-Process -FilePath $setup -ArgumentList $arguments -WindowStyle Hidden -PassThru
    if (-not $process.WaitForExit(60000)) { $process.Kill(); throw "Installer timeout: $target" }
    if ($expectedExit -eq 0) { Assert ($process.ExitCode -eq 0) "installer exit code $($process.ExitCode)" }
    else { Assert ($process.ExitCode -ne 0) 'backup failure blocks installation' }
}
function VerifyPayload($target) {
    foreach ($entry in $inventory.files.PSObject.Properties) {
        $path = Join-Path $target $entry.Name
        Assert ((Test-Path -LiteralPath $path) -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -eq $entry.Value) "installed $($entry.Name)"
    }
    Assert ((Get-FileHash -LiteralPath (Join-Path $target 'release-files.json') -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath (Join-Path $dist 'release-files.json') -Algorithm SHA256).Hash) 'installed inventory matches bundle'
    Assert (@(Get-ChildItem -LiteralPath $target -Recurse -File | Where-Object { $_.Name -match 'Regression|test-installer|^qa$' }).Count -eq 0) 'no QA executables packaged'
}
# Verify test mode does not modify existing application shortcuts or uninstall registration.
$shortcut = Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Khet70.lnk'
$shortcutBefore = if (Test-Path -LiteralPath $shortcut) { (Get-FileHash -LiteralPath $shortcut).Hash } else { '' }
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Khet70_is1'
$registryBefore = if (Test-Path -LiteralPath $key) { (Get-ItemProperty -LiteralPath $key | Out-String) } else { '' }
$clean = Join-Path $work 'clean-install'
Install $clean
VerifyPayload $clean
Assert (Test-Path -LiteralPath (Join-Path $clean 'Data\.portable-state-migrated-v1')) 'installer prevents importing unrelated AppData templates'
$target = Join-Path $work 'upgrade-install'
Copy-Item -LiteralPath $clean -Destination $target -Recurse
$legacy = if ($LegacyExe) { (Resolve-Path $LegacyExe).Path } else { Join-Path $root 'qa\defender-20260929-investigation\appdata-installer-20260929-120200\artifacts\payload\Khet70\Khet70.exe' }
if (-not (Test-Path -LiteralPath $legacy)) { throw 'Historical executable fixture missing; supply a pre-updater Khet70.exe' }
Copy-Item -LiteralPath $legacy -Destination (Join-Path $target 'Khet70.exe') -Force
Assert ([version]([Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $target 'Khet70.exe')).FileVersion) -lt [version]"$($inventory.version).0") 'upgrade fixture runs an older executable'
$data = Join-Path $target 'Data\Payroll'
$output = Join-Path $target 'Output\เงินเดือน'
New-Item -ItemType Directory -Path $data,$output -Force | Out-Null
$saved = Join-Path $data 'saved_templates.json'
$generated = Join-Path $output 'existing-document.docx'
[IO.File]::WriteAllText($saved, '{"user":"preserve older user records"}')
[IO.File]::WriteAllText($generated, 'existing generated document')
$savedHash = (Get-FileHash -LiteralPath $saved).Hash
$outputHash = (Get-FileHash -LiteralPath $generated).Hash
$relativeTemplate = 'Payroll\3. ใบส่งมอบงาน.docx'
$oldTemplate = Join-Path $target "Template\$relativeTemplate"
[IO.File]::WriteAllText($oldTemplate, 'old user-customized template')
$templateHash = (Get-FileHash -LiteralPath $oldTemplate).Hash
[IO.File]::WriteAllText((Join-Path $target 'app_database.json'), 'stale defaults')
[IO.File]::WriteAllText((Join-Path $target 'Config\app_identity.json'), 'stale config')
$obsolete = Join-Path $target 'Template\Procurement\9. ใบสั่งจ้าง.docx'
[IO.File]::WriteAllText($obsolete, 'old obsolete template')
Install $target
VerifyPayload $target
Assert ((Get-FileHash -LiteralPath $saved).Hash -eq $savedHash) 'user Data preserved byte-for-byte'
Assert ((Get-FileHash -LiteralPath $generated).Hash -eq $outputHash) 'user Output preserved byte-for-byte'
$backups = @(Get-ChildItem -LiteralPath (Join-Path $target 'Data\TemplateBackups') -Directory)
Assert ($backups.Count -eq 1) 'one template backup created'
Assert ((Get-FileHash -LiteralPath (Join-Path $backups[0].FullName $relativeTemplate)).Hash -eq $templateHash) 'backup preserves customized template'
Assert (Test-Path -LiteralPath (Join-Path $backups[0].FullName 'Procurement\9. ใบสั่งจ้าง.docx')) 'obsolete template backed up before removal'
Assert (-not (Test-Path -LiteralPath $obsolete)) 'explicit obsolete template removed'
Install $target
Assert (@(Get-ChildItem -LiteralPath (Join-Path $target 'Data\TemplateBackups') -Directory).Count -eq 2) 'same-version reinstall creates another backup'
$blocked = Join-Path $work 'blocked-backup'
New-Item -ItemType Directory -Path (Join-Path $blocked 'Data'),(Join-Path $blocked 'Template') -Force | Out-Null
Copy-Item -LiteralPath $legacy -Destination (Join-Path $blocked 'Khet70.exe')
[IO.File]::WriteAllText((Join-Path $blocked 'Data\TemplateBackups'), 'not a directory')
[IO.File]::WriteAllText((Join-Path $blocked 'Template\custom.docx'), 'keep')
$oldExeHash = (Get-FileHash -LiteralPath (Join-Path $blocked 'Khet70.exe')).Hash
Install $blocked 1
Assert ((Get-FileHash -LiteralPath (Join-Path $blocked 'Khet70.exe')).Hash -eq $oldExeHash) 'backup failure leaves original executable untouched'
$shortcutAfter = if (Test-Path -LiteralPath $shortcut) { (Get-FileHash -LiteralPath $shortcut).Hash } else { '' }
$registryAfter = if (Test-Path -LiteralPath $key) { (Get-ItemProperty -LiteralPath $key | Out-String) } else { '' }
Assert ($shortcutBefore -eq $shortcutAfter) 'real desktop shortcut unchanged'
Assert ($registryBefore -eq $registryAfter) 'real uninstall registration unchanged'
Write-Output "Installer evidence: $work"
