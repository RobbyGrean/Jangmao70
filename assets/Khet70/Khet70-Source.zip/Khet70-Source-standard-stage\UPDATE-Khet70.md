# Khet70 update release

Version 1.1.0 introduces the update feature. Users of older versions must download and install the new Khet70-Setup.exe once. On reopening, the update and program information buttons appear above all tabs.

Edit DOCX originals under Template/Payroll and Template/Procurement. Run refresh-template-hashes.ps1 to refresh the corresponding Config hashes and verify all 49 files, then build. TemplateKhet70new is not a build input. All 18 routes use A=4, B=สี่, C=2, D=สอง; the page tags remain supported even when contracts use fixed text.

Khet70-release.json supplies the version and verified GitHub repository. The owner confirmed RobbyGrean/Jangmao70, branch main, path assets/Khet70. This repository hosts both products; Khet70 must use only its assets/Khet70 files. A blank repository deliberately disables network updates. Do not publish a QA build made with -AllowUnpublished.

Build with powershell -NoProfile -ExecutionPolicy Bypass -File .\build-installer-Khet70.ps1. Output is copied to assets/Khet70 with the existing Installer ZIP and Source ZIP names, standard aliases, direct Setup.exe, Khet70-Checksums.txt and update.json. Application, installer, inventory and manifest versions match. QA artifacts/test programs are excluded from the installer. Source ZIP includes regression scripts but excludes investigation output and downloaded reference source.

Updates run only when requested. The app confirms before downloading, checks SHA256, then uses the existing save/close flow. A canceled or failed save never schedules installation. A temporary copy of the executable waits for the original process to exit, rechecks SHA256 and the target version, and launches Inno Setup with /DIR pointing to the running application's directory. Update installation does not automatically reopen the app. Pending receipts live under that installation's Data and contain its absolute path.

Inno Setup preserves Data/Output, backs up Template into Data/TemplateBackups, replaces shipped program/config/template/default files, and marks portable migration complete so AppData templates cannot overwrite the installed update. On reopening, the app checks version, the SHA256-bound release-files.json inventory and all shipped files before reporting success. Editable templates are excluded from same-version repair detection but included in immediate post-install validation.

Before publication run verify-release-Khet70.ps1. Commit Setup.exe and update.json together with the complete download bundle. Publishing requires explicit authorization. Afterwards fetch live Raw update.json and Setup.exe and compare hashes. Until that passes, record only that local artifacts were prepared. Resolve GitHub 404 before claiming a distributable update build is ready.

Regression commands after building (Windows PowerShell): qa/run-update-regression.ps1, qa/helper-launch-regression.ps1, qa/installer-upgrade-regression.ps1. The upgrade test needs a historical executable; when running from an extracted Source ZIP provide -LegacyExe with a pre-updater Khet70.exe. Tests use separate folders and /ISOLATEDTEST so real shortcuts and uninstall registration are unchanged. This switch omits the uninstaller and shortcuts only for QA; normal installation uses the original Inno Setup installation behavior.
