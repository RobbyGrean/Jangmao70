﻿param([string]$ManifestPath = (Join-Path $PSScriptRoot '..\assets\Khet70\update.json'))
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$run = Join-Path $PSScriptRoot 'update-run'
if ([IO.Path]::GetFullPath($run) -ne (Join-Path $root 'qa\update-run')) { throw 'Unexpected QA path' }
if (Test-Path -LiteralPath $run) { Remove-Item -LiteralPath $run -Recurse -Force }
New-Item -ItemType Directory -Path $run | Out-Null
Copy-Item -Path (Join-Path $root 'dist\Khet70\*') -Destination $run -Recurse -Force
$sources = @('Khet70App.cs','Khet70Shell.cs','Shared\Khet70Core.cs','Shared\Khet70Config.cs','Shared\TemplateTransfer.cs','Shared\DocxRenderer.cs','Shared\Khet70Update.cs','Shared\Khet70ReleaseInfo.cs','Modules\Procurement\ProcurementModule.cs','qa\UpdaterRegression.cs') | ForEach-Object { Join-Path $root $_ }
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$exe = Join-Path $run 'UpdaterRegression.exe'
& $csc /nologo /codepage:65001 /target:exe /main:UpdaterRegression "/out:$exe" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll $sources
if ($LASTEXITCODE -ne 0) { throw 'Updater regression compilation failed' }
$process = New-Object Diagnostics.Process
$process.StartInfo.FileName = $exe
$process.StartInfo.Arguments = '"' + (Resolve-Path $ManifestPath).Path + '"'
$process.StartInfo.UseShellExecute = $false
$process.StartInfo.CreateNoWindow = $true
$process.StartInfo.RedirectStandardOutput = $true
$process.StartInfo.RedirectStandardError = $true
$process.StartInfo.StandardOutputEncoding = New-Object Text.UTF8Encoding($false)
$process.StartInfo.StandardErrorEncoding = New-Object Text.UTF8Encoding($false)
[void]$process.Start()
$stdout = $process.StandardOutput.ReadToEndAsync()
$stderr = $process.StandardError.ReadToEndAsync()
if (-not $process.WaitForExit(60000)) { $process.Kill(); throw 'Updater regression exceeded 60 seconds' }
$result = $stdout.GetAwaiter().GetResult()
$errors = $stderr.GetAwaiter().GetResult()
[IO.File]::WriteAllText((Join-Path $run 'results.txt'), $result, (New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText((Join-Path $run 'errors.txt'), $errors, (New-Object Text.UTF8Encoding($false)))
Write-Output $result
if ($process.ExitCode -ne 0) { Write-Output $errors; throw "Updater regression failed (exit=$($process.ExitCode))" }
$process.Dispose()
