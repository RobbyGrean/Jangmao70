using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Khet70
{
    internal sealed class UpdateManifest
    {
        public int schemaVersion { get; set; }
        public string product { get; set; }
        public string version { get; set; }
        public string installerUrl { get; set; }
        public string installerSha256 { get; set; }
        public string payloadSha256 { get; set; }
    }

    internal sealed class ReleaseFiles
    {
        public string version { get; set; }
        public Dictionary<string, string> files { get; set; }
    }

    internal sealed class PendingUpdate
    {
        public UpdateManifest manifest { get; set; }
        public string appDirectory { get; set; }
        public string installerPath { get; set; }
        public int processId { get; set; }
        public long processStartTicks { get; set; }
    }

    internal static class Khet70Update
    {
        public static string VersionText { get { return Khet70ReleaseInfo.Version; } }
        public static string ManifestUrl { get { return Khet70ReleaseInfo.DownloadBaseUrl + "/update.json"; } }
        public static string InstallerUrl { get { return Khet70ReleaseInfo.DownloadBaseUrl + "/Khet70-Setup.exe"; } }
        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

        private sealed class UpdateClient : WebClient
        {
            protected override WebRequest GetWebRequest(Uri address)
            {
                var request = base.GetWebRequest(address);
                request.Timeout = 30000;
                var http = request as HttpWebRequest;
                if (http != null) http.ReadWriteTimeout = 30000;
                return request;
            }
        }

        private static WebClient CreateClient()
        {
            if (string.IsNullOrEmpty(Khet70ReleaseInfo.DownloadBaseUrl))
                throw new InvalidOperationException("ยังไม่ได้กำหนด GitHub repository ของ Khet70 กรุณาติดต่อผู้ดูแลโปรแกรม");
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            var client = new UpdateClient();
            client.Encoding = Encoding.UTF8;
            client.Headers[HttpRequestHeader.UserAgent] = "Khet70/" + VersionText;
            client.Headers[HttpRequestHeader.CacheControl] = "no-cache";
            return client;
        }

        public static async Task<UpdateManifest> CheckAsync()
        {
            using (var client = CreateClient())
            {
                var download = client.DownloadStringTaskAsync(ManifestUrl + "?check=" + Guid.NewGuid().ToString("N"));
                if (await Task.WhenAny(download, Task.Delay(30000)) != download)
                {
                    client.CancelAsync();
                    try { await download; } catch { }
                    throw new TimeoutException("ตรวจสอบอัปเดตเกินเวลา 30 วินาที กรุณาลองใหม่ภายหลัง");
                }
                return ParseManifest(await download);
            }
        }

        public static UpdateManifest ParseManifest(string json)
        {
            var manifest = Json.Deserialize<UpdateManifest>(json);
            Version version;
            if (manifest == null || manifest.schemaVersion != 1 || manifest.product != "Khet70"
                || !Version.TryParse(manifest.version, out version) || version.Build < 0 || version.Revision > 0
                || manifest.installerUrl != InstallerUrl || string.IsNullOrEmpty(Khet70ReleaseInfo.DownloadBaseUrl)
                || !IsHash(manifest.installerSha256) || !IsHash(manifest.payloadSha256))
                throw new InvalidDataException("ข้อมูลอัปเดต Khet70 ไม่ถูกต้อง กรุณาติดต่อผู้ดูแลโปรแกรม");
            manifest.version = version.ToString(3);
            return manifest;
        }

        private static bool IsHash(string value)
        {
            return value != null && Regex.IsMatch(value, "\\A[0-9a-fA-F]{64}\\z");
        }

        public static string HashFile(string path)
        {
            using (var input = File.OpenRead(path))
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(input)).Replace("-", "");
        }

        public static bool NeedsUpdate(UpdateManifest manifest)
        {
            var available = new Version(manifest.version);
            var current = new Version(VersionText);
            // Equal versions may repair shipped files. User-editable Template is checked only after installation.
            return available > current || (available == current && !MatchesPayload(AppDomain.CurrentDomain.BaseDirectory, manifest, false));
        }

        public static async Task<string> DownloadAsync(UpdateManifest manifest, Action<int> progress)
        {
            manifest = ParseManifest(Json.Serialize(manifest));
            EnsureNoDowngrade(manifest);
            var directory = Path.Combine(Path.GetTempPath(), "Khet70-Updates", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            var path = Path.Combine(directory, "Khet70-Setup.exe");
            try
            {
                using (var client = CreateClient())
                {
                    client.DownloadProgressChanged += delegate(object sender, DownloadProgressChangedEventArgs e) { if (progress != null) progress(e.ProgressPercentage); };
                    var download = client.DownloadFileTaskAsync(manifest.installerUrl + "?download=" + Guid.NewGuid().ToString("N"), path);
                    if (await Task.WhenAny(download, Task.Delay(300000)) != download)
                    {
                        client.CancelAsync();
                        try { await download; } catch { }
                        throw new TimeoutException("ดาวน์โหลดเกินเวลา 5 นาที กรุณาลองใหม่ภายหลัง");
                    }
                    await download;
                }
                VerifyInstaller(path, manifest.installerSha256);
                return path;
            }
            catch
            {
                if (File.Exists(path)) File.Delete(path);
                throw;
            }
        }

        public static void VerifyInstaller(string path, string expectedHash)
        {
            if (!IsHash(expectedHash) || !string.Equals(HashFile(path), expectedHash, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("SHA256 ของไฟล์ติดตั้งไม่ตรงกับข้อมูลอัปเดต จะไม่เรียกตัวติดตั้ง กรุณาดาวน์โหลดใหม่");
        }

        private static void EnsureNoDowngrade(UpdateManifest manifest)
        {
            if (new Version(manifest.version) < new Version(VersionText))
                throw new InvalidDataException("ไม่อนุญาตให้ติดตั้งรุ่นเก่ากว่าโปรแกรมที่เปิดอยู่");
        }

        // Called only after FormClosed, so save cancellation never starts a helper or writes a receipt.
        public static void ScheduleInstaller(string installer, UpdateManifest manifest)
        {
            manifest = ParseManifest(Json.Serialize(manifest));
            EnsureNoDowngrade(manifest);
            VerifyInstaller(installer, manifest.installerSha256);
            var directory = Path.GetDirectoryName(installer);
            var helper = Path.Combine(directory, "Khet70-UpdateHelper.exe");
            File.Copy(Application.ExecutablePath, helper, true);
            using (var process = Process.GetCurrentProcess())
            {
                var request = new PendingUpdate { manifest = manifest, appDirectory = AppDomain.CurrentDomain.BaseDirectory,
                    installerPath = installer, processId = process.Id, processStartTicks = process.StartTime.ToUniversalTime().Ticks };
                var requestPath = Path.Combine(directory, "request.json");
                File.WriteAllText(requestPath, Json.Serialize(request), new UTF8Encoding(false));
                Process.Start(new ProcessStartInfo(helper, "--apply-update \"" + requestPath + "\"") { UseShellExecute = false, CreateNoWindow = true });
            }
        }

        public static void ApplyAfterExit(string requestPath)
        {
            var request = Json.Deserialize<PendingUpdate>(File.ReadAllText(requestPath));
            request.manifest = ParseManifest(Json.Serialize(request.manifest));
            EnsureNoDowngrade(request.manifest);
            try
            {
                using (var process = Process.GetProcessById(request.processId))
                {
                    if (process.StartTime.ToUniversalTime().Ticks == request.processStartTicks && !process.WaitForExit(60000))
                        throw new TimeoutException("โปรแกรมเดิมยังไม่ปิด จึงไม่เริ่มติดตั้ง กรุณาเปิดโปรแกรมแล้วลองใหม่");
                }
            }
            catch (ArgumentException) { /* Original process already exited. */ }
            var appExe = Path.Combine(request.appDirectory, "Khet70.exe");
            if (!File.Exists(appExe)) throw new FileNotFoundException("ไม่พบโปรแกรมปลายทาง", appExe);
            if (new Version(FileVersionInfo.GetVersionInfo(appExe).FileVersion) > new Version(request.manifest.version + ".0"))
                throw new InvalidDataException("โปรแกรมปลายทางเป็นรุ่นใหม่กว่าแล้ว จึงไม่ติดตั้งรุ่นเก่า");
            VerifyInstaller(request.installerPath, request.manifest.installerSha256);
            var data = Path.Combine(request.appDirectory, "Data");
            Directory.CreateDirectory(data);
            var pendingPath = Path.Combine(data, "pending-update.json");
            File.WriteAllText(pendingPath, Json.Serialize(request), new UTF8Encoding(false));
            // Keep a read lock while creating the installer process, preventing a write between hash and launch.
            using (var guard = File.Open(request.installerPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                VerifyInstaller(request.installerPath, request.manifest.installerSha256);
                Process.Start(new ProcessStartInfo(request.installerPath, "/DIR=\"" + request.appDirectory.TrimEnd('\\') + "\" /NORESTART /NOAUTORUN") { UseShellExecute = true });
            }
        }

        public static bool MatchesPayload(string root, UpdateManifest manifest, bool includeEditableTemplates)
        {
            var inventoryPath = Path.Combine(root, "release-files.json");
            if (!File.Exists(inventoryPath) || !string.Equals(HashFile(inventoryPath), manifest.payloadSha256, StringComparison.OrdinalIgnoreCase)) return false;
            var inventory = Json.Deserialize<ReleaseFiles>(File.ReadAllText(inventoryPath));
            if (inventory == null || inventory.version != manifest.version || inventory.files == null || inventory.files.Count == 0
                || !inventory.files.ContainsKey("Khet70.exe") || !inventory.files.ContainsKey("app_database.json")
                || !inventory.files.ContainsKey("Config/app_identity.json")) return false;
            foreach (var item in inventory.files)
            {
                var relative = item.Key.Replace('\\', '/');
                if (!IsHash(item.Value) || !(relative == "Khet70.exe" || relative == "template_tags.json" || relative == "app_database.json"
                    || relative.StartsWith("Config/", StringComparison.Ordinal) || relative.StartsWith("Template/", StringComparison.Ordinal)
                    || relative.StartsWith("Defaults/Template/", StringComparison.Ordinal))) return false;
                var path = Path.GetFullPath(Path.Combine(root, relative));
                if (!path.StartsWith(Path.GetFullPath(root).TrimEnd('\\', '/') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) return false;
                if (!includeEditableTemplates && relative.StartsWith("Template/", StringComparison.Ordinal)) continue;
                if (!File.Exists(path) || !string.Equals(HashFile(path), item.Value, StringComparison.OrdinalIgnoreCase)) return false;
            }
            return true;
        }

        public static string ReadUpdateResult(string root)
        {
            var path = Path.Combine(root, "Data", "pending-update.json");
            if (!File.Exists(path)) return null;
            var pending = Json.Deserialize<PendingUpdate>(File.ReadAllText(path));
            if (pending == null || !string.Equals(Path.GetFullPath(pending.appDirectory).TrimEnd('\\', '/'), Path.GetFullPath(root).TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase)) return null;
            pending.manifest = ParseManifest(Json.Serialize(pending.manifest));
            if (new Version(VersionText) != new Version(pending.manifest.version) || !MatchesPayload(root, pending.manifest, true))
                return "การอัปเดตยังไม่ครบ หรือยกเลิกการติดตั้งไว้ กรุณากดอัปเดตโปรแกรมอีกครั้ง\n\nไฟล์ที่เปิดอยู่: " + Application.ExecutablePath;
            File.Delete(path);
            return "อัปเดตสำเร็จ รุ่น " + VersionText + "\nตรวจสอบไฟล์โปรแกรม Config และ Template แล้ว\n\n" + Application.ExecutablePath;
        }
    }
}
