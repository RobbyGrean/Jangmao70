using System;
using System.Diagnostics;
using System.IO;
using System.Web.Script.Serialization;
using System.Collections.Generic;
internal static class UpdateInstallerProbe
{
    private static void Main(string[] args)
    {
        var directory = AppDomain.CurrentDomain.BaseDirectory;
        var json = new JavaScriptSerializer();
        var request = json.Deserialize<Dictionary<string, object>>(File.ReadAllText(Path.Combine(directory, "request.json")));
        var originalStillRunning = false;
        try { using (var original = Process.GetProcessById(Convert.ToInt32(request["processId"]))) originalStillRunning = !original.HasExited; }
        catch (ArgumentException) { }
        File.WriteAllText(Path.Combine(directory, "installer-probe.json"), json.Serialize(new { arguments = args, originalStillRunning = originalStillRunning }));
    }
}
