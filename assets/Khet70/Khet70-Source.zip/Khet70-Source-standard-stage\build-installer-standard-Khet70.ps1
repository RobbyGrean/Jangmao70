﻿param([switch]$AllowUnpublished)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path $PSScriptRoot).Path
$info = Get-Content -LiteralPath (Join-Path $root 'Khet70-release.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($info.repository) -and -not $AllowUnpublished) {
    throw 'Set the verified Khet70 repository in Khet70-release.json before building a release. Use -AllowUnpublished only for local QA.'
}
$dist = Join-Path $root 'dist\Khet70'
$release = Join-Path $root 'release\Khet70-Installer'
$setup = Join-Path $release 'Khet70-Setup.exe'
$iscc = (Get-Command 'iscc.exe' -ErrorAction SilentlyContinue).Source
if ([string]::IsNullOrWhiteSpace($iscc)) {
    foreach ($candidate in @('C:\Program Files (x86)\Inno Setup 6\ISCC.exe', 'C:\Program Files\Inno Setup 6\ISCC.exe', 'C:\Users\MSI\AppData\Local\Programs\Inno Setup 6\ISCC.exe')) {
        if (Test-Path -LiteralPath $candidate) { $iscc = $candidate; break }
    }
}
if ([string]::IsNullOrWhiteSpace($iscc)) { throw 'Inno Setup Compiler (ISCC.exe) is required' }
& (Join-Path $root 'verify-manifest.ps1')
& (Join-Path $root 'build-exe-Khet70.ps1')
foreach ($test in @('payroll-renderer-regression', 'date-validation-regression', 'render-all-regression')) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "qa\$test.ps1") -ExePath (Join-Path $dist 'Khet70.exe')
    if ($LASTEXITCODE -ne 0) { throw "Regression failed: $test" }
}
if (@(Get-ChildItem -LiteralPath (Join-Path $dist 'Template') -Filter '*.docx' -Recurse -File).Count -ne 49) { throw 'Expected 49 packaged DOCX templates' }
New-Item -ItemType Directory -Path $release -Force | Out-Null
& $iscc "/O$release" "/DMyAppVersion=$($info.version)" (Join-Path $root 'Khet70-Setup.iss')
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup compilation failed' }
$appVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $dist 'Khet70.exe')).FileVersion
$setupVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($setup).FileVersion
if ([version]$appVersion -ne [version]$setupVersion -or [version]$appVersion -ne [version]"$($info.version).0") { throw 'App/installer/release version mismatch' }
$installerZip = Join-Path $root 'release\Khet70-Installer-standard.zip'
Compress-Archive -LiteralPath $setup -DestinationPath $installerZip -Force
Copy-Item -LiteralPath $installerZip -Destination (Join-Path $root 'release\Khet70-Installer.zip') -Force
Copy-Item -LiteralPath $setup -Destination (Join-Path $root 'release\Khet70-Setup.exe') -Force
$sourceStage = Join-Path $root 'release\Khet70-Source-standard-stage'
if ([IO.Path]::GetFullPath($sourceStage) -ne (Join-Path $root 'release\Khet70-Source-standard-stage')) { throw 'Unexpected stage path' }
if (Test-Path -LiteralPath $sourceStage) { Remove-Item -LiteralPath $sourceStage -Recurse -Force }
New-Item -ItemType Directory -Path $sourceStage | Out-Null
# Explicit source list excludes user data, artifacts and investigation/reference downloads.
foreach ($name in @('Config','Shared','Modules','Template','qa','Khet70App.cs','Khet70Shell.cs','Khet70Installer.cs','Khet70Uninstaller.cs','Khet70-Setup.iss','Khet70-release.json','build-exe-Khet70.ps1','build-installer-Khet70.ps1','build-installer-standard-Khet70.ps1','refresh-template-hashes.ps1','verify-manifest.ps1','verify-release-Khet70.ps1','README.md','UPDATE-Khet70.md','template_tags.json','app-icon.ico','app-logo-worker.png')) {
    if ($name -eq 'qa') {
        $qaStage = Join-Path $sourceStage 'qa'
        New-Item -ItemType Directory -Path $qaStage | Out-Null
        Get-ChildItem -LiteralPath (Join-Path $root 'qa') -File | Where-Object { $_.Extension -in '.ps1','.cs' } | Copy-Item -Destination $qaStage -Force
    } else { Copy-Item -LiteralPath (Join-Path $root $name) -Destination $sourceStage -Recurse -Force }
}
$sourceZip = Join-Path $root 'release\Khet70-Source-standard.zip'
Compress-Archive -LiteralPath $sourceStage -DestinationPath $sourceZip -Force
Copy-Item -LiteralPath $sourceZip -Destination (Join-Path $root 'release\Khet70-Source.zip') -Force
Remove-Item -LiteralPath $sourceStage -Recurse -Force
$downloadRoot = Join-Path $root $info.downloadPath
New-Item -ItemType Directory -Path $downloadRoot -Force | Out-Null
foreach ($name in @('Khet70-Setup.exe','Khet70-Installer.zip','Khet70-Installer-standard.zip','Khet70-Source.zip','Khet70-Source-standard.zip')) {
    Copy-Item -LiteralPath (Join-Path $root "release\$name") -Destination (Join-Path $downloadRoot $name) -Force
}
$base = ''
if ($info.repository) { $base = "https://raw.githubusercontent.com/$($info.repository)/$($info.branch)/$($info.downloadPath)" }
$manifest = [ordered]@{
    schemaVersion = 1
    product = 'Khet70'
    version = $info.version
    installerUrl = $(if ($base) { "$base/Khet70-Setup.exe" } else { '' })
    installerSha256 = (Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash
    payloadSha256 = (Get-FileHash -LiteralPath (Join-Path $dist 'release-files.json') -Algorithm SHA256).Hash
}
[IO.File]::WriteAllText((Join-Path $downloadRoot 'update.json'), ($manifest | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
Copy-Item -LiteralPath (Join-Path $downloadRoot 'update.json') -Destination (Join-Path $root 'release\update.json') -Force
$checksums = foreach ($name in @('Khet70-Setup.exe','Khet70-Installer.zip','Khet70-Installer-standard.zip','Khet70-Source.zip','Khet70-Source-standard.zip','update.json')) {
    "$( (Get-FileHash -LiteralPath (Join-Path $downloadRoot $name) -Algorithm SHA256).Hash )  $name"
}
$checksums | Set-Content -LiteralPath (Join-Path $downloadRoot 'Khet70-Checksums.txt') -Encoding ASCII
Copy-Item -LiteralPath (Join-Path $downloadRoot 'Khet70-Checksums.txt') -Destination (Join-Path $root 'release\Khet70-Checksums.txt') -Force
& (Join-Path $root 'verify-release-Khet70.ps1') -DownloadRoot $downloadRoot -AllowUnpublished:$AllowUnpublished
Write-Host "Prepared Khet70 $($info.version): $downloadRoot (local files; not published)"
